/* ===================================================================
   Auth UI — login/register modal + header user info + logout.
   Blocks the app until the person is logged in, then tells the rest
   of the app (todo.js, timer.js, song.js) it's safe to load data by
   firing "focus:authenticated" (see api.js).
=================================================================== */

$(function () {

    const overlay = $("#auth-overlay");
    const panel = $("#auth-panel");

    const loginForm = $("#login-form");
    const registerForm = $("#register-form");

    const loginError = $("#login-error");
    const registerError = $("#register-error");


    function showAuth() {

        overlay.addClass("show");
        panel.addClass("show");

        if (typeof window.setProfileUser === "function") window.setProfileUser(null);
    }

    window.focusOpenAuth = function () {
        showAuth();
        setTimeout(function(){ $("#login-email").trigger("focus"); }, 120);
    };

    // Close the auth modal without logging the user out.
    $(document).on("click", "#close-auth, #auth-overlay", function (e) {
        if (e.target.id === "auth-overlay" || e.target.id === "close-auth" || $(e.target).closest("#close-auth").length) {
            overlay.removeClass("show");
            panel.removeClass("show");
        }
    });

    $(document).on("keydown", function (e) {
        if (e.key === "Escape") {
            overlay.removeClass("show");
            panel.removeClass("show");
        }
    });

    function hideAuth(user) {

        overlay.removeClass("show");
        panel.removeClass("show");

        if (typeof window.setProfileUser === "function") window.setProfileUser(user);
    }

    function setLoading(form, isLoading) {

        form.find("button[type=submit]")
            .prop("disabled", isLoading)
            .toggleClass("loading", isLoading);
    }

    /* -------------------- tabs -------------------- */

    $(".auth-tab").on("click", function () {

        const tab = $(this).data("tab");

        $(".auth-tab").removeClass("active");
        $(this).addClass("active");

        loginError.text("");
        registerError.text("");

        if (tab === "login") {

            loginForm.removeClass("d-none");
            registerForm.addClass("d-none");

        } else {

            registerForm.removeClass("d-none");
            loginForm.addClass("d-none");
        }
    });

    /* -------------------- login -------------------- */

    loginForm.on("submit", async function (e) {

        e.preventDefault();

        loginError.text("");

        const email = $("#login-email").val().trim();
        const password = $("#login-password").val();

        setLoading(loginForm, true);

        try {

            const result = await FocusAPI.auth.login(email, password);

            FocusAuth.setToken(result.token);

            hideAuth(result.user);

            broadcastAuthenticated(result.user);

        } catch (err) {

            loginError.text(err.message);

        } finally {

            setLoading(loginForm, false);
        }
    });

    /* -------------------- register -------------------- */

    registerForm.on("submit", async function (e) {

        e.preventDefault();

        registerError.text("");

        const name = $("#register-name").val().trim();
        const email = $("#register-email").val().trim();
        const password = $("#register-password").val();

        setLoading(registerForm, true);

        try {

            const result = await FocusAPI.auth.register(name, email, password);

            FocusAuth.setToken(result.token);

            hideAuth(result.user);

            broadcastAuthenticated(result.user);

        } catch (err) {

            registerError.text(err.message);

        } finally {

            setLoading(registerForm, false);
        }
    });

    $(document).on("click", "#profile-admin-action", function () { window.location.href = "admin.html"; });

    /* -------------------- logout -------------------- */

    $(document).on("click", "#profile-logout-action", function () {

        FocusAuth.clearToken();

        broadcastLoggedOut();
        if (typeof window.setProfileUser === "function") window.setProfileUser(null);

        // reset forms so the next login starts clean
        loginForm[0].reset();
        registerForm[0].reset();
        loginError.text("");
        registerError.text("");

        // Do not reopen the authentication modal automatically after logout.
        // The user can open it again from the profile icon.
        overlay.removeClass("show");
        panel.removeClass("show");
    });

    /* -------------------- boot -------------------- */

    async function boot() {

        if (!FocusAuth.isLoggedIn()) {
            if (typeof window.setProfileUser === "function") window.setProfileUser(null);
            return;
        }

        try {

            const result = await FocusAPI.auth.me();

            hideAuth(result.user);

            broadcastAuthenticated(result.user);

        } catch (err) {

            // token missing/expired/invalid -> back to login
            FocusAuth.clearToken();
            if (typeof window.setProfileUser === "function") window.setProfileUser(null);
        }
    }

    boot();

});
