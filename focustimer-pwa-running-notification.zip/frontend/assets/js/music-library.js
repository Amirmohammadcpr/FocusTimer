const MUSIC_LIBRARY = [

    {
        title: "Study Lofi",
        artist: "Lofi",
        file: "assets/music/d.mp3",
        is_vip: true
    },

    {
        title: "Bookstore",
        artist: "Lofi",
        file: "assets/music/e.mp3",
        is_vip: true
    },

    {
        title: "Bookstore 2",
        artist: "Lofi",
        file: "assets/music/f.mp3",
        is_vip: true
    },

    {
        title: "Space lofi",
        artist: "Nature",
        file: "assets/music/g.mp3",
        is_vip: false
    },

    {
        title: "Night peace",
        artist: "peace",
        file: "assets/music/a.mp3",
        is_vip: false
    },

    {
        title: "Under the sea",
        artist: "Ocean",
        file: "assets/music/b.mp3",
        is_vip: false
    },

    {
        title: "pacific",
        artist: "Ocean",
        file: "assets/music/c.mp3",
        is_vip: false
    }

];