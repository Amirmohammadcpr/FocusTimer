$(document).ready(function () {
  function removeAllSidebarToggleClass() {
    $("#sidebar-toggle-hide").removeClass("d-md-inline");
    $("#sidebar-toggle-hide").removeClass("d-none");
    $("#sidebar-toggle-show").removeClass("d-inline");
    $("#sidebar-toggle-show").removeClass("d-md-none");
  }

  $("#sidebar-toggle-hide").click(function (e) {
    $("#sidebar").fadeOut(300);
    $("#main-body").animate({ width: "100%" }, 300);
    setTimeout(function () {
      removeAllSidebarToggleClass();
      $("#sidebar-toggle-hide").addClass("d-none");
      $("#sidebar-toggle-show").removeClass("d-none");
    }, 300);
  });

  $("#sidebar-toggle-show").click(function (e) {
    $("#sidebar").fadeIn(300);
    setTimeout(function () {
      removeAllSidebarToggleClass();
      // $('#sidebar-toggle-hide').removeClass('d-none');
      $("#sidebar-toggle-show").addClass("d-none");
    }, 300);
  });

  $("#menu-toggle").click(function (e) {
    $("#body-header").toggle(300);
  });

  $("#search-toggle").click(function (e) {
    $("#search-toggle").removeClass("d-md-inline");
    $("#search-area").addClass("d-md-inline");
    $("#search-input").animate({ width: "12rem" }, 300);
  });

  $("#search-area-hide").click(function (e) {
    $("#search-input").animate({ width: "0" }, 300);
    setTimeout(function () {
      $("#search-toggle").addClass("d-md-inline");
      $("#search-area").removeClass("d-md-inline");
    }, 300);
  });

  $("#header-notification-toggle").click(function (e) {
    $("#header-notification").fadeToggle(300);
  });

  $("#header-comment-toggle").click(function (e) {
    $("#header-comment").fadeToggle(300);
  });

  $("#header-profile-toggle").click(function (e) {
    $("#header-profile").fadeToggle(300);
  });

  $(".sidebar-group-link").click(function (e) {
    $(".sidebar-group-link").removeClass("sidebar-group-link-active");
    $(".sidebar-group-link")
      .children(".sidebar-dropdown-toggle")
      .children(".angle")
      .removeClass("fa-angle-down");
    $(".sidebar-group-link")
      .children(".sidebar-dropdown-toggle")
      .children(".angle")
      .addClass("fa-angle-left");

    $(this).addClass("sidebar-group-link-active");
    $(this)
      .children(".sidebar-dropdown-toggle")
      .children(".angle")
      .removeClass("fa-angle-left");
    $(this)
      .children(".sidebar-dropdown-toggle")
      .children(".angle")
      .addClass("fa-angle-down");
  });

  $("#full-screen").click(function (e) {
    toggleFullScreen();
    // $('.screen-compress').removeClass('d-none');
    // $('.screen-expand').addClass('d-none');
  });

  function toggleFullScreen() {
    if (
      (document.fullScreenElement && document.fullScreenElement !== null) ||
      (!document.mozFullScreen && !document.webkitIsFullScreen)
    ) {
      if (document.documentElement.requestFullscreen) {
        document.documentElement.requestFullscreen();
      } else if (document.documentElement.mozRequestFullscreen) {
        document.documentElement.mozRequestFullscreen();
      } else if (document.documentElement.webkitRequestFullscreen) {
        document.documentElement.webkitRequestFullscreen(
          Element.ALLOW_KEYBOARD_INPUT,
        );
      }

      $("#screen-compress").removeClass("d-none");
      $("#screen-expand").addClass("d-none");
    } else {
      if (document.cancelFullScreen) {
        document.cancelFullScreen();
      } else if (document.mozCancelFullScreen) {
        document.mozCancelFullScreen();
      } else if (document.webkitCancelFullScreen) {
        document.webkitCancelFullScreen();
      }
      $("#screen-compress").addClass("d-none");
      $("#screen-expand").removeClass("d-none");
    }
  }

  $("#profile-toggle").click(function (e) {
    $("#sidebar").fadeToggle(300);
  });

  $("#full-screen").click(function (e) {
    toggleFullScreen();
    $(".screen-compress").removeClass("d-none");
    $(".screen-expand").addClass("d-none");
  });


//
//   // تنظیمات اولیه تایمر پومودورو
//   let focusTime = .2 * 60; // زمان تمرکز (۲۵ دقیقه)
//   let breakTime = .2 * 60; // زمان استراحت (۵ دقیقه)
//   let remaining = focusTime; // مقدار اولیه برای شروع
//   let timerInterval = null;
//   let isFocusing = true; // وضعیت فعلی: تمرکز یا استراحت
//
//   // تابع تولید صدای Beep
//   function playBeep() {
//     const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
//     const oscillator = audioCtx.createOscillator();
//     oscillator.type = "sine";
//     oscillator.frequency.setValueAtTime(400, audioCtx.currentTime);
//     oscillator.connect(audioCtx.destination);
//     oscillator.start();
//     oscillator.stop(audioCtx.currentTime + 0.5);
//   }
//
//
//   // تابع فرمت کردن زمان به صورت mm:ss
//   function formatTime(sec) {
//     let m = Math.floor(sec / 60);
//     let s = sec % 60;
//     return (m < 10 ? "0" + m : m) + ":" + (s < 10 ? "0" + s : s);
//   }
//
//   // تابع برای کنترل نمایش/مخفی کردن دکمه Toggle
//   function toggleButtonVisibility() {
//     if (timerInterval) {
//       // اگر تایمر در حال اجراست، دکمه Toggle را مخفی کن
//       $("#toggle-mode").hide();
//     } else {
//       // اگر تایمر در حال اجرا نیست، دکمه Toggle را نمایش بده
//       $("#toggle-mode").show();
//     }
//   }
//
//   // نمایش مقدار اولیه تایمر و وضعیت
//   $("#timer").text(formatTime(remaining));
//   $("#status").text(" : Pomodoro ");
//   toggleButtonVisibility();
//   // تابع اصلی برای مدیریت زمان و جابجایی بین حالت‌ها
//   function startTimerLogic() {
//     if (timerInterval) return; // جلوگیری از چندبار استارت
//
//     timerInterval = setInterval(() => {
//
//       remaining--;
//
//       if (remaining < 0) {
//
//         clearInterval(timerInterval);
//         timerInterval = null;
//
//         playBeep();
//
//         if (isFocusing) {
//
//           isFocusing = false;
//           remaining = breakTime;
//
//           $("#status").text("Short break");
//
//           $("#mode-icon")
//               .removeClass("fa-brain")
//               .addClass("fa-mug-hot");
//
//         } else {
//
//           isFocusing = true;
//           remaining = focusTime;
//
//           $("#status").text("Pomodoro");
//
//           $("#mode-icon")
//               .removeClass("fa-mug-hot")
//               .addClass("fa-brain");
//         }
//
//         $("#timer").text(formatTime(remaining));
//
//         $("#timer").text(formatTime(remaining));
//
//         startTimerLogic();
//
//         return;
//       }
//
//       $("#timer").text(formatTime(remaining));
//
//     }, 1000);
//     toggleButtonVisibility();
//   }
//
//   // دکمه Start (فقط برای شروع اولیه یا بعد از توقف)
//   $("#start-time").click(function () {
//     startTimerLogic();
//   });
//
//   // دکمه Stop
//   $("#stop-time").click(function () {
//     clearInterval(timerInterval);
//     timerInterval = null;
//     // toggleButtonVisibility()
//   });
//
//   $("#reset").click(function () {
//     clearInterval(timerInterval);
//     timerInterval = null;
//
//     // اگر در حالت تمرکز بودیم
//     if (isFocusing) {
//       remaining = focusTime;
//       $("#status").text(" : Pomodoro ");
//     }
//     // اگر در حالت استراحت بودیم
//     else {
//       remaining = breakTime;
//       $("#status").text(" : Short break ");
//     }
//
//     $("#timer").text(formatTime(remaining));
//
//     $("#toggle-mode").show();
//
//     // آیکون‌ها به حالت اولیه PLAY
//     $("#start-time").removeClass("d-none");
//     $("#stop-time").addClass("d-none");
//   });
//
//
//   $("#toggle-mode").click(function () {
//
//     if (isFocusing) {
//
//       remaining = breakTime;
//       $("#timer").text(formatTime(remaining));
//
//       $("#status").text("Break");
//       $("#mode-icon")
//           .removeClass("fa-brain")
//           .addClass("fa-mug-hot");
//
//       isFocusing = false;
//
//     } else {
//
//       remaining = focusTime;
//       $("#timer").text(formatTime(remaining));
//
//       $("#status").text("Pomodoro");
//       $("#mode-icon")
//           .removeClass("fa-mug-hot")
//           .addClass("fa-brain");
//
//       isFocusing = true;
//     }
//
//   // ریست یا ادامه تایمر، بسته به وضعیت و تنظیمات
//   if (timerInterval) {
//     clearInterval(timerInterval);
//     timerInterval = null;
//     startTimerLogic(); // ← شروع مجدد تایمر با مقدار جدید
//   }
//
//   toggleButtonVisibility(); // ← بروزرسانی دکمه‌های استارت/استاپ
// });


  ///////theme change (Free + VIP)

  const FREE_THEMES = ["theme-default", "theme-dark", "theme-blue"];
  let availableThemes = [...FREE_THEMES];
  let themeCatalog = {};
  let currentTheme = 0;
  let currentVipState = { active: false };
  let allThemeClasses = [...FREE_THEMES, "chill", "gensihin", "gensihin2", "car"];

  function applyTheme() {
    const themeId = availableThemes[currentTheme] || FREE_THEMES[0];
    const theme = themeCatalog[themeId] || null;
    $("body")
      .removeClass(allThemeClasses.join(" "))
      .addClass(themeId);
    if (theme && theme.backgroundUrl) {
      document.body.style.backgroundImage = `url("${theme.backgroundUrl}")`;
      document.body.style.backgroundSize = "cover";
      document.body.style.backgroundPosition = "center";
      document.body.style.backgroundAttachment = "fixed";
    } else {
      document.body.style.backgroundImage = "";
      document.body.style.backgroundAttachment = "";
    }
    localStorage.setItem("focus_theme", themeId);
  }

  function showThemeLocked() {
    const message = "این تم VIP است؛ برای شروع تایمر باید VIP داشته باشید ⭐";
    if (window.showThemeVipToast) {
      window.showThemeVipToast(message);
      return;
    }
    alert(message);
  }

  function isCurrentThemeVip() {
    const themeId = availableThemes[currentTheme] || FREE_THEMES[0];
    return Boolean(themeCatalog[themeId] && (themeCatalog[themeId].isVip === true || themeCatalog[themeId].is_vip === true));
  }

  window.isCurrentThemeVip = isCurrentThemeVip;
  window.isCurrentThemeUsable = () => currentVipState.active || !isCurrentThemeVip();
  window.openVipRequirementPrompt = function(message) {
    const text = message || "برای استفاده از این قابلیت روی این تم، نیاز به VIP دارید ⭐";
    if (window.showThemeVipToast) { window.showThemeVipToast(text); return; }
    alert(text);
  };

  async function loadThemeAccess() {
    try {
      if (!FocusAuth.isLoggedIn()) {
        const previewCatalog = [
          ...FREE_THEMES.map(id => ({ id, isVip: false, backgroundUrl: null })),
          ...["chill", "gensihin", "gensihin2", "car"].map(id => ({ id, isVip: true, backgroundUrl: null }))
        ];
        themeCatalog = {};
        previewCatalog.forEach(theme => { themeCatalog[theme.id] = theme; });
        availableThemes = previewCatalog.map(theme => theme.id);
        allThemeClasses = Array.from(new Set([...allThemeClasses, ...availableThemes]));
        const saved = localStorage.getItem("focus_theme");
        currentTheme = saved && availableThemes.includes(saved) ? availableThemes.indexOf(saved) : 0;
        return;
      }

      const result = await FocusAPI.vip.themes();
      currentVipState = result.vip || (await FocusAPI.vip.status()).vip || { active: false };
      const catalog = result.themes || FREE_THEMES.map(id => ({ id, isVip: false, backgroundUrl: null }));
      themeCatalog = {};
      catalog.forEach(theme => { themeCatalog[theme.id] = theme; });
      availableThemes = catalog.map(theme => theme.id);
      allThemeClasses = Array.from(new Set([...allThemeClasses, ...availableThemes]));

      const saved = localStorage.getItem("focus_theme");
      if (saved && availableThemes.includes(saved)) {
        currentTheme = availableThemes.indexOf(saved);
      } else {
        currentTheme = 0;
      }
    } catch (err) {
      currentVipState = { active: false };
      availableThemes = [...FREE_THEMES];
      currentTheme = Math.max(0, availableThemes.indexOf(localStorage.getItem("focus_theme")));
    }
  }

  async function saveTheme(themeName) {
    const theme = themeCatalog[themeName] || {};
    const isVipTheme = theme.isVip === true || theme.is_vip === true;
    const canPersist = currentVipState.active || !isVipTheme;
    // Preview is intentionally local-only for guests/free users on VIP themes.
    if (!FocusAuth.isLoggedIn() || !canPersist) {
      localStorage.setItem("focus_theme", themeName);
      return;
    }
    await FocusAPI.settings.update({ themeName });
  }

  async function changeTheme(direction) {
    const nextIndex = currentTheme + direction;
    if (nextIndex < 0 || nextIndex >= availableThemes.length) return;

    const previousIndex = currentTheme;
    currentTheme = nextIndex;
    const themeName = availableThemes[currentTheme];

    try {
      await saveTheme(themeName);
      applyTheme();
    } catch (err) {
      currentTheme = previousIndex;
      console.error("Theme save failed:", err);
    }
  }

  $("#theme-next").click(() => changeTheme(1));
  $("#theme-prev").click(() => changeTheme(-1));

  // Apply a persisted/default Free theme immediately, then refresh VIP access.
  const initialTheme = localStorage.getItem("focus_theme");
  FREE_THEMES.forEach(id => { themeCatalog[id] = { id, isVip: false, backgroundUrl: null }; });
  currentTheme = FREE_THEMES.includes(initialTheme) ? FREE_THEMES.indexOf(initialTheme) : 0;
  applyTheme();

  loadThemeAccess().then(() => applyTheme());

});