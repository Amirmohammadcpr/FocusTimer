$(function () {
  let page = 1, currentPanel = "overview";
  const limit = 12;
  const esc = (v) => String(v ?? "").replace(/[&<>"']/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[ch]));
  const date = v => v ? new Date(v).toLocaleString("fa-IR") : "—";
  const money = v => Number(v || 0).toLocaleString("fa-IR");
  const msg = e => alert(e?.message || "خطای نامشخص");

  async function boot(){
    if(!FocusAuth.isLoggedIn()) return showDenied("ابتدا وارد حساب ادمین شوید.");
    try{
      const me=await FocusAPI.auth.me();
      if(!(me.user?.isAdmin===true || me.user?.role==="admin")) return showDenied("این حساب دسترسی ادمین ندارد.");
      $("#admin-auth").addClass("d-none"); $("#admin-app").removeClass("d-none"); $("#admin-welcome").text(" — "+me.user.name);
      await loadOverview(); await loadContent(); await loadSettings();
    }catch(e){showDenied(e.message||"دسترسی رد شد.");}
  }
  function showDenied(t){$("#admin-auth-error").text(t); $("#admin-login-btn").off("click").on("click",()=>location.href="index.html");}

  async function loadOverview(){
    const [d,p]=await Promise.all([FocusAPI.admin.dashboard(),FocusAPI.admin.payments({limit:20})]);
    const s=d.stats;
    $("#stat-users").text(money(s.users)); $("#stat-vip").text(money(s.activeVip)); $("#stat-admins").text(money(s.admins)); $("#stat-paid").text(money(s.paidPayments)); $("#stat-revenue").text(money(s.revenue)); $("#stat-pending").text(money(s.pendingPayments));
    const ru=$("#recent-users-tbody").empty(); (d.recentUsers||[]).forEach(u=>ru.append(`<tr><td>${esc(u.name)}</td><td>${esc(u.email)}</td><td>${u.role==='admin'?'Admin':'User'}</td><td>${u.vip_status==='active'?'VIP':'Free'}</td><td>${date(u.created_at)}</td></tr>`));
    renderPayments(p, "#recent-payments-tbody");
    await loadUsers();
  }

  async function loadUsers(){
    const r=await FocusAPI.admin.users({page,limit,search:$("#user-search").val(),vip:$("#user-vip-filter").val()});
    const tb=$("#users-tbody").empty();
    r.users.forEach(u=>{const vip=u.vip?.active; tb.append(`<tr><td><strong>${esc(u.name)}</strong><small>${esc(u.email)}</small></td><td><span class="admin-pill ${u.role==='admin'?'admin-pill-admin':''}">${u.role==='admin'?'Admin':'User'}</span></td><td><span class="admin-pill ${u.isActive===false?'status-failed':'status-paid'}">${u.isActive===false?'غیرفعال':'فعال'}</span></td><td><span class="admin-pill ${vip?'admin-pill-vip':''}">${vip?'VIP':'Free'}</span></td><td>${date(u.vip?.expiresAt)}</td><td class="admin-actions-cell"><button class="admin-small-btn user-view" data-id="${u.id}">جزئیات</button><button class="admin-small-btn user-vip" data-id="${u.id}">VIP</button><button class="admin-small-btn user-status" data-id="${u.id}" data-active="${u.isActive!==false}">${u.isActive===false?'فعال‌سازی':'غیرفعال'}</button><button class="admin-small-btn user-role" data-id="${u.id}" data-role="${u.role}">${u.role==='admin'?'User':'Admin'}</button><button class="admin-small-btn user-pass" data-id="${u.id}">رمز</button></td></tr>`);});
    const max=Math.max(1,Math.ceil((r.total||0)/(r.limit||limit))); $("#users-page").text(`صفحه ${r.page} از ${max}`); $("#users-prev").prop('disabled',page<=1); $("#users-next").prop('disabled',page>=max);
  }

  async function loadSubscriptions(){
    const r=await FocusAPI.admin.subscriptions({limit:200}); const tb=$("#subscriptions-tbody").empty();
    r.subscriptions.forEach(s=>tb.append(`<tr><td><strong>${esc(s.user_name)}</strong><small>${esc(s.user_email)}</small></td><td>${esc(s.plan_id)}</td><td><span class="admin-pill ${s.status==='active'?'status-paid':s.status==='pending'?'status-pending':'status-failed'}">${esc(s.status)}</span></td><td>${date(s.started_at)}</td><td>${date(s.expires_at)}</td><td>${esc(s.provider)}</td><td class="admin-actions-cell"><button class="admin-small-btn sub-extend" data-id="${s.id}">تمدید</button>${s.status==='active'?`<button class="admin-small-btn sub-cancel" data-id="${s.id}">لغو</button>`:''}</td></tr>`));
  }

  async function loadPayments(){
    const r=await FocusAPI.admin.payments({limit:200,status:$("#payment-status-filter").val(),search:$("#payment-search").val()}); renderPayments(r,"#payments-tbody");
  }
  function renderPayments(r, selector){const tb=$(selector).empty(); (r.payments||r||[]).forEach(p=>tb.append(`<tr><td><code>${esc(p.payment_id)}</code></td><td><strong>${esc(p.user_name||'')}</strong><small>${esc(p.user_email||'')}</small></td><td>${esc(p.plan_id)}</td><td>${money(p.amount)} ${esc(p.currency)}</td><td>${esc(p.provider)}</td><td><span class="admin-pill ${p.status==='paid'?'status-paid':p.status==='pending'?'status-pending':'status-failed'}">${esc(p.status)}</span></td><td>${date(p.created_at)}</td></tr>`));}

  async function loadContent(){await loadSongs();await loadThemes();}
  async function loadSongs(){
    const r=await FocusAPI.admin.songs();
    const tb=$("#admin-songs-tbody").empty();
    (r.songs||[]).forEach(s=>tb.append(`<tr><td><strong>${esc(s.title)}</strong><small>${esc(s.artist)}</small><small>${esc(s.file_url)}</small></td><td><span class="admin-pill ${s.is_vip?'admin-pill-vip':''}">${s.is_vip?'VIP ⭐':'Free'}</span></td><td><button class="admin-small-btn song-toggle" data-id="${s.id}" data-vip="${s.is_vip?1:0}">${s.is_vip?'Free کردن':'VIP کردن'}</button><button class="admin-small-btn song-edit" data-id="${s.id}" data-title="${esc(s.title)}" data-artist="${esc(s.artist)}" data-url="${esc(s.file_url)}">ویرایش</button><button class="admin-small-btn song-delete" data-id="${s.id}">حذف</button></td></tr>`));
  }
  async function loadThemes(){
    const r=await FocusAPI.admin.themes();
    const tb=$("#admin-themes-tbody").empty();
    (r.themes||[]).forEach(t=>tb.append(`<tr><td><strong>${esc(t.name)}</strong><small>${esc(t.theme_key)}</small>${t.background_url||t.backgroundUrl?`<small>🖼️ پس‌زمینه دارد</small>`:'<small>بدون پس‌زمینه</small>'}</td><td>${esc(t.css_file)}</td><td><span class="admin-pill ${t.is_vip?'admin-pill-vip':''}">${t.is_vip?'VIP ⭐':'Free'}</span></td><td><button class="admin-small-btn theme-toggle" data-id="${t.id}" data-vip="${t.is_vip?1:0}">${t.is_vip?'Free کردن':'VIP کردن'}</button><button class="admin-small-btn theme-enabled" data-id="${t.id}" data-enabled="${t.enabled?1:0}">${t.enabled?'غیرفعال':'فعال'}</button><button class="admin-small-btn theme-upload-bg" data-id="${t.id}">آپلود پس‌زمینه</button><button class="admin-small-btn theme-delete" data-id="${t.id}">حذف</button></td></tr>`));
  }

  async function loadSettings(){const r=await FocusAPI.admin.settings();const s=r.settings||{};$("#set-registration").val(s.site_registration_enabled??'1');$("#set-maintenance").val(s.site_maintenance_mode??'0');$("#set-max-todos").val(s.max_free_todos??10);$("#set-monthly").val(s.vip_monthly_price_irr??0);$("#set-quarterly").val(s.vip_quarterly_price_irr??0);$("#set-yearly").val(s.vip_yearly_price_irr??0);}
  async function loadAudit(){const r=await FocusAPI.admin.auditLogs({limit:300});const tb=$("#audit-tbody").empty();(r.logs||[]).forEach(l=>tb.append(`<tr><td><strong>${esc(l.admin_name||'سیستم')}</strong><small>${esc(l.admin_email||'')}</small></td><td>${esc(l.action)}</td><td>${esc((l.target_type||'')+' '+(l.target_id||''))}</td><td><code>${esc(l.details||'')}</code></td><td>${date(l.created_at)}</td></tr>`));}

  $(".admin-nav-btn").on("click",async function(){const p=$(this).data('panel');currentPanel=p;$(".admin-nav-btn").removeClass('active');$(this).addClass('active');$(".admin-panel-view").removeClass('active');$(`[data-panel-view="${p}"]`).addClass('active');try{if(p==='users')await loadUsers();if(p==='subscriptions')await loadSubscriptions();if(p==='payments')await loadPayments();if(p==='content')await loadContent();if(p==='settings')await loadSettings();if(p==='audit')await loadAudit();}catch(e){msg(e);}});

  $("#user-search-btn").on('click',()=>{page=1;loadUsers().catch(msg)});$("#users-prev").on('click',()=>{if(page>1){page--;loadUsers().catch(msg)}});$("#users-next").on('click',()=>{page++;loadUsers().catch(msg)});
  $(document).on('click','.user-vip',async function(){const id=Number($(this).data('id'));const plan=prompt('پلن: monthly / quarterly / yearly','monthly');if(!plan)return;try{await FocusAPI.admin.activateVip(id,plan);await loadUsers();}catch(e){msg(e);}});
  $(document).on('click','.user-status',async function(){const id=Number($(this).data('id'));const current=String($(this).attr('data-active'))==='true'; const active=!current;try{await FocusAPI.admin.setActive(id,active);await loadUsers();}catch(e){msg(e);}});
  $(document).on('click','.user-role',async function(){const id=Number($(this).data('id'));const role=$(this).data('role')==='admin'?'user':'admin';if(!confirm(`نقش به ${role} تغییر کند؟`))return;try{await FocusAPI.admin.setRole(id,role);await loadUsers();}catch(e){msg(e);}});
  $(document).on('click','.user-pass',async function(){const id=Number($(this).data('id'));const p=prompt('رمز جدید (حداقل ۶ کاراکتر):');if(!p)return;try{await FocusAPI.admin.resetPassword(id,p);alert('رمز عبور تغییر کرد.');}catch(e){msg(e);}});
  $(document).on('click','.user-view',async function(){const id=Number($(this).data('id'));try{const r=await FocusAPI.admin.user(id);alert(`کاربر: ${r.user.name}\nایمیل: ${r.user.email}\nنقش: ${r.user.role}\nVIP: ${r.user.vip?.active?'فعال':'Free'}\nاشتراک‌ها: ${r.subscriptions?.length||0}\nپرداخت‌ها: ${r.payments?.length||0}\nجلسات: ${r.activity?.sessions||0}\nTo-Do: ${r.activity?.todos||0}`);}catch(e){msg(e);}});

  $(document).on('click','.sub-cancel',async function(){if(!confirm('اشتراک لغو شود؟'))return;try{await FocusAPI.admin.cancelSubscription($(this).data('id'));await loadSubscriptions();}catch(e){msg(e);}});
  $(document).on('click','.sub-extend',async function(){const days=prompt('چند روز تمدید شود؟','30');if(!days)return;try{await FocusAPI.admin.extendSubscription($(this).data('id'),Number(days));await loadSubscriptions();}catch(e){msg(e);}});

  $("#payment-search-btn").on('click',()=>loadPayments().catch(msg));
  async function readFileAsDataUrl(file, maxBytes, allowedPrefix, allowedMimes) {
    if (!file) return null;
    if (file.size > maxBytes) throw new Error(`حجم فایل بیشتر از ${Math.floor(maxBytes/1024/1024)}MB است.`);
    if (!allowedMimes.includes(file.type)) throw new Error('نوع فایل مجاز نیست.');
    return await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onerror = () => reject(new Error('خواندن فایل انجام نشد.'));
      reader.onload = () => resolve(reader.result);
      reader.readAsDataURL(file);
    });
  }

  $("#song-add").on('click',async()=>{
    try{
      const title=$("#song-title").val().trim(),artist=$("#song-artist").val().trim(),fileUrl=$("#song-url").val().trim(),file=$("#song-file")[0]?.files?.[0];
      if(!title||!artist) return alert('عنوان و هنرمند را وارد کنید.');
      const isVip=$("#song-vip").prop('checked');
      if(file){
        if(file.size > 1024*1024*1024) return alert('حجم موزیک نباید بیشتر از 1GB باشد.');
        if(!/^audio\/(mpeg|mp3|wav|x-wav|ogg|aac|mp4|x-m4a)$/i.test(file.type)) return alert('فرمت موزیک پشتیبانی نمی‌شود.');
        const button=$("#song-add").prop('disabled',true).text('در حال آپلود 0%');
        try {
          await FocusAPI.admin.uploadSongChunked(file,{title,artist,isVip},(done,total)=>button.text('در حال آپلود '+Math.floor(done/total*100)+'%'));
        } finally { button.prop('disabled',false).text('افزودن'); }
      } else {
        if(!fileUrl) return alert('یا فایل موزیک را انتخاب کن یا URL آن را وارد کن.');
        await FocusAPI.admin.createSong({title,artist,isVip,fileUrl});
      }
      $("#song-title,#song-artist,#song-url").val(''); $("#song-file").val(''); $("#song-vip").prop('checked',false); await loadSongs();
    }catch(e){msg(e);}
  });
  $(document).on('click','.song-toggle',async function(){try{await FocusAPI.admin.updateSong($(this).data('id'),{isVip:!Boolean(Number($(this).data('vip')))});await loadSongs();}catch(e){msg(e);}});
  $(document).on('click','.song-edit',async function(){const id=Number($(this).data('id'));const title=prompt('عنوان',$(this).data('title'));if(title===null)return;const artist=prompt('هنرمند',$(this).data('artist'));if(artist===null)return;const url=prompt('URL فایل (برای فایل آپلودی خالی بگذار)',$(this).data('url'));if(url===null)return;try{await FocusAPI.admin.updateSong(id,{title,artist,fileUrl:url});await loadSongs();}catch(e){msg(e);}});
  $(document).on('click','.song-delete',async function(){if(!confirm('این موزیک حذف شود؟ فایل آپلودی هم پاک می‌شود.'))return;try{await FocusAPI.admin.deleteSong($(this).data('id'));await loadSongs();}catch(e){msg(e);}});

  $("#theme-add").on('click',async()=>{
    try{
      const themeKey=$("#theme-key").val().trim(),name=$("#theme-name").val().trim(),cssFile=$("#theme-css").val().trim(),file=$("#theme-background-file")[0]?.files?.[0];
      if(!themeKey||!name)return alert('Theme Key و نام را وارد کنید.');
      const isVip=$("#theme-vip").prop('checked');
      if(file){
        if(file.size > 100*1024*1024) return alert('حجم پس‌زمینه Theme نباید بیشتر از 100MB باشد.');
        if(!/^image\/(jpeg|png|webp|gif)$/i.test(file.type)) return alert('فرمت تصویر پشتیبانی نمی‌شود.');
        const button=$("#theme-add").prop('disabled',true).text('در حال ساخت Theme...');
        try {
          const created=await FocusAPI.admin.createTheme({themeKey,name,cssFile,isVip});
          button.text('در حال آپلود 0%');
          await FocusAPI.admin.uploadThemeBackgroundChunked(created.theme.id,file,(done,total)=>button.text('در حال آپلود '+Math.floor(done/total*100)+'%'));
        } finally { button.prop('disabled',false).text('افزودن'); }
      } else {
        await FocusAPI.admin.createTheme({themeKey,name,cssFile,isVip});
      }
      $("#theme-key,#theme-name,#theme-css").val('');$("#theme-background-file").val('');$("#theme-vip").prop('checked',false);await loadThemes();
    }catch(e){msg(e);}
  });
  $(document).on('click','.theme-toggle',async function(){try{await FocusAPI.admin.updateTheme($(this).data('id'),{isVip:!Boolean(Number($(this).data('vip')))});await loadThemes();}catch(e){msg(e);}});
  $(document).on('click','.theme-enabled',async function(){try{await FocusAPI.admin.updateTheme($(this).data('id'),{enabled:!Boolean(Number($(this).data('enabled')))});await loadThemes();}catch(e){msg(e);}});
  $(document).on('click','.theme-upload-bg',async function(){
    const id=Number($(this).data('id'));
    const input=$('<input type="file" accept="image/jpeg,image/png,image/webp,image/gif">');
    input.on('change',async()=>{const file=input[0].files?.[0];if(!file)return;try{if(file.size>100*1024*1024)throw new Error('حجم تصویر نباید بیشتر از 100MB باشد.');if(!/^image\/(jpeg|png|webp|gif)$/i.test(file.type))throw new Error('فرمت تصویر پشتیبانی نمی‌شود.');await FocusAPI.admin.uploadThemeBackgroundChunked(id,file,()=>{});await loadThemes();}catch(e){msg(e);}});
    input.trigger('click');
  });
  $(document).on('click','.theme-delete',async function(){if(!confirm('این تم غیرفعال شود؟ فایل پس‌زمینه آپلودی هم پاک می‌شود.'))return;try{await FocusAPI.admin.deleteTheme($(this).data('id'));await loadThemes();}catch(e){msg(e);}});

  $("#settings-save").on('click',async()=>{try{await FocusAPI.admin.updateSettings({site_registration_enabled:$("#set-registration").val(),site_maintenance_mode:$("#set-maintenance").val(),max_free_todos:$("#set-max-todos").val(),vip_monthly_price_irr:$("#set-monthly").val(),vip_quarterly_price_irr:$("#set-quarterly").val(),vip_yearly_price_irr:$("#set-yearly").val()});alert('تنظیمات ذخیره شد.');}catch(e){msg(e);}});

  $("#admin-refresh").on('click',async()=>{try{await loadOverview();if(currentPanel==='subscriptions')await loadSubscriptions();if(currentPanel==='payments')await loadPayments();if(currentPanel==='content')await loadContent();if(currentPanel==='settings')await loadSettings();if(currentPanel==='audit')await loadAudit();}catch(e){msg(e);}});
  $("#admin-statistics").on('click',()=>location.href='admin-statistics.html');$("#admin-back").on('click',()=>location.href='index.html');
  boot();
});
