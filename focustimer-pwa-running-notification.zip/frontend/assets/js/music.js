/* ===================================
   Elements
=================================== */

// Panel
const musicPanel = document.getElementById("music-panel");
const musicOverlay = document.getElementById("music-overlay");
const musicList = document.getElementById("music-list");
const musicSearch = document.getElementById("music-search-input");
const musicButton = document.getElementById("music-btn");
const closeMusic = document.getElementById("close-music");

// Audio
const audio = document.getElementById("music-audio");

// Player
const playerTitle = document.getElementById("player-title");
const playerArtist = document.getElementById("player-artist");
const currentTime = document.getElementById("current-time");
const durationTime = document.getElementById("duration-time");

const progressBar = document.querySelector(".player-progress .progress");
const progressFill = document.getElementById("music-progress");

// Controls
const playBtn = document.getElementById("play-song");
const prevBtn = document.getElementById("prev-song");
const nextBtn = document.getElementById("next-song");

const shuffleBtn = document.getElementById("shuffle-btn");
const loopBtn = document.getElementById("loop-btn");


/* ===================================
   Variables
=================================== */

let currentSong = -1;

let isPlaying = false;

let isShuffle = false;

let isLoop = false;

/* ===================================
   Core Functions
=================================== */

// ساخت لیست موزیک‌ها

// function renderMusic(list = MUSIC_LIBRARY){
//
//     musicList.innerHTML = "";
//
//     list.forEach((song,index)=>{
//
//         const item = document.createElement("div");
//
//         item.className = "music-item";
//
//         item.dataset.index = index;
//
//         item.innerHTML = `
//
//             <div class="music-info">
//
//                 <span class="music-title">${song.title}</span>
//
//                 <span class="music-artist">${song.artist}</span>
//
//             </div>
//
//             <span class="music-duration">--:--</span>
//
//         `;
//
//         item.addEventListener("click",()=>{
//
//             loadSong(index);
//
//             playMusic();
//
//         });
//         musicList.appendChild(item);
//
//
//
//     });
//
// }

function renderMusic(list = MUSIC_LIBRARY){
    console.log(list);
    console.log(musicList);

    musicList.innerHTML = "";
    musicList.innerHTML = "";

    list.forEach((song)=>{

        // پیدا کردن اندیس واقعی آهنگ داخل کتابخانه
        const realIndex = MUSIC_LIBRARY.findIndex(
            item => item.file === song.file
        );

        const item = document.createElement("div");

        item.className = "music-item";

        item.dataset.index = realIndex;

        item.innerHTML = `
            <div class="music-info">

                <span class="music-title">${song.title}</span>

                <span class="music-artist">${song.artist}</span>

            </div>

            <span class="music-duration">--:--</span>
        `;

        item.addEventListener("click", () => {

            loadSong(realIndex);

            playMusic();

        });

        musicList.appendChild(item);

    });

}



// بارگذاری موزیک
function loadSong(index){

    currentSong = index;

    const song = MUSIC_LIBRARY[index];

    audio.src = song.file;

    playerTitle.textContent = song.title;

    playerArtist.textContent = song.artist;

    document.querySelectorAll(".music-item").forEach(item=>{

        item.classList.remove("active");

    });

    document
        .querySelector(`[data-index="${index}"]`)
        ?.classList.add("active");

    updateMusicMini();

}



// پخش
function playMusic(){

    if(currentSong === -1) return;

    audio.play();

    isPlaying = true;

    playBtn.innerHTML =

        '<i class="fa-solid fa-pause"></i>';

    updateMusicMini();
    updateMiniPlayButton();

}



// توقف
function pauseMusic(){

    audio.pause();

    isPlaying = false;

    playBtn.innerHTML =

        '<i class="fa-solid fa-play"></i>';
    updateMiniPlayButton();
}



// آهنگ بعدی
function nextSong(){

    if(isShuffle){

        currentSong = Math.floor(
            Math.random() * MUSIC_LIBRARY.length
        );

    }else{

        currentSong++;

        if(currentSong >= MUSIC_LIBRARY.length){

            currentSong = 0;

        }

    }

    loadSong(currentSong);

    playMusic();

}



// آهنگ قبلی
function prevSong(){

    currentSong--;

    if(currentSong < 0){

        currentSong = MUSIC_LIBRARY.length - 1;

    }

    loadSong(currentSong);

    playMusic();

}



// تبدیل ثانیه به دقیقه
function formatTime(time){

    const min = Math.floor(time / 60);

    const sec = Math.floor(time % 60);

    return `${min}:${sec.toString().padStart(2,"0")}`;

}

/* ===================================
   Event Listeners
=================================== */

// باز کردن پنل
musicButton.addEventListener("click",()=>{

    musicPanel.classList.add("show");

    musicOverlay.classList.add("show");

});

// بستن پنل
function closePanel(){

    musicPanel.classList.remove("show");

    musicOverlay.classList.remove("show");

}

closeMusic.addEventListener("click",closePanel);

musicOverlay.addEventListener("click",closePanel);


// جستجو
musicSearch.addEventListener("input",()=>{

    const value = musicSearch.value.toLowerCase();

    const filtered = MUSIC_LIBRARY.filter(song=>{

        return(

            song.title.toLowerCase().includes(value)

            ||

            song.artist.toLowerCase().includes(value)

        );

    });

    renderMusic(filtered);

});


// Play / Pause
playBtn.addEventListener("click",()=>{

    if(currentSong === -1){

        loadSong(0);

        playMusic();

        return;

    }

    if(isPlaying){

        pauseMusic();

    }else{

        playMusic();

    }

});


// آهنگ بعدی
nextBtn.addEventListener("click",nextSong);


// آهنگ قبلی
prevBtn.addEventListener("click",prevSong);


// Loop
loopBtn.addEventListener("click",()=>{

    isLoop = !isLoop;

    audio.loop = isLoop;

    loopBtn.classList.toggle("active");

});


// Shuffle
shuffleBtn.addEventListener("click",()=>{

    isShuffle = !isShuffle;

    shuffleBtn.classList.toggle("active");

});


// وقتی موزیک لود شد
audio.addEventListener("loadedmetadata",()=>{

    durationTime.textContent = formatTime(audio.duration);

});


// آپدیت Progress
audio.addEventListener("timeupdate",()=>{

    if(audio.duration){

        const percent =
            (audio.currentTime / audio.duration) * 100;

        progressFill.style.width = percent + "%";

    }

    currentTime.textContent =
        formatTime(audio.currentTime);

});


// کلیک روی Progress Bar
progressBar.addEventListener("click",(e)=>{

    if(!audio.duration) return;

    const rect = progressBar.getBoundingClientRect();

    const percent =
        (e.clientX - rect.left) / rect.width;

    audio.currentTime =
        percent * audio.duration;

});


// پایان آهنگ
audio.addEventListener("ended",()=>{

    if(isLoop){

        playMusic();

        return;

    }

    nextSong();

});


/* ===================================
   Initialize
=================================== */

renderMusic();

