const musicMiniPlayer = document.getElementById("music-mini-player");

const musicMiniTitle = document.getElementById("music-mini-title");
const musicMiniArtist = document.getElementById("music-mini-artist");

const musicMiniProgress = document.getElementById("music-mini-progress-fill");

const musicMiniPlay = document.getElementById("music-mini-play");
const musicMiniPrev = document.getElementById("music-mini-prev");
const musicMiniNext = document.getElementById("music-mini-next");

function updateMusicMini(){

    if(currentSong === -1) return;

    musicMiniTitle.textContent =
        MUSIC_LIBRARY[currentSong].title;

    musicMiniArtist.textContent =
        MUSIC_LIBRARY[currentSong].artist;

    musicMiniPlayer.classList.add("show");

}

musicMiniPlay.addEventListener("click",()=>{

    if(isPlaying){

        pauseMusic();

    }else{

        playMusic();

    }

});

musicMiniNext.addEventListener("click",()=>{

    nextSong();

});

musicMiniPrev.addEventListener("click",()=>{

    prevSong();

});

audio.addEventListener("timeupdate",()=>{

    if(audio.duration){

        musicMiniProgress.style.width =

            (audio.currentTime / audio.duration) * 100 + "%";

    }

});

musicMiniPlay.addEventListener("click",toggleMiniPlayer);

function toggleMiniPlayer(){

    if(currentSong === -1){

        loadSong(0);

        playMusic();
        updateMiniPlayButton();
        return;

    }

    if(isPlaying){

        pauseMusic();

    }else{

        playMusic();

    }

}

function updateMiniPlayButton(){

    musicMiniPlay.innerHTML = isPlaying ?

        '<i class="fa-solid fa-pause"></i>'

        :

        '<i class="fa-solid fa-play"></i>';


}
const musicMiniClose = document.getElementById("music-mini-close");

musicMiniClose.addEventListener("click",()=>{

    musicMiniPlayer.classList.remove("show");

});






