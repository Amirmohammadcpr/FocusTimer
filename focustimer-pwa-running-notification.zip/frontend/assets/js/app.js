document.addEventListener('DOMContentLoaded',()=>{
const timerEl=document.getElementById('timer');
const statusEl=document.getElementById('status');
const resetBtn=document.getElementById('reset');
const toggleBtn=document.getElementById('toggle-mode');

let focus=25*60, brk=5*60;
let isFocus=true;
let remaining=Number(localStorage.getItem('remaining'))||focus;
let timer=null;

function fmt(s){return String(Math.floor(s/60)).padStart(2,'0')+':'+String(s%60).padStart(2,'0');}
function render(){
 timerEl.textContent=fmt(remaining);
 statusEl.textContent=isFocus?' : Pomodoro ':' : Short break ';
 localStorage.setItem('remaining',remaining);
 localStorage.setItem('isFocus',isFocus);
}
function start(){
 if(timer) return;
 timer=setInterval(()=>{
   if(remaining>0){remaining--; render();}
   else{
      isFocus=!isFocus;
      remaining=isFocus?focus:brk;
      render();
   }
 },1000);
}
function reset(){
 clearInterval(timer); timer=null;
 remaining=isFocus?focus:brk;
 render();
}
resetBtn?.addEventListener('click',reset);
toggleBtn?.addEventListener('click',()=>{
 isFocus=!isFocus;
 remaining=isFocus?focus:brk;
 render();
});
render();
});
