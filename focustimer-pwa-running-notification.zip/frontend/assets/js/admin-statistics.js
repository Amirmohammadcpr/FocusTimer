(() => {
  const $ = (id) => document.getElementById(id);
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const fa = (v) => Number(v || 0).toLocaleString('fa-IR');
  const money = (v) => Number(v || 0).toLocaleString('fa-IR');
  const dateFa = (v) => v ? new Date(v + (String(v).length === 10 ? 'T00:00:00' : '')).toLocaleDateString('fa-IR', { month: '2-digit', day: '2-digit' }) : '—';
  const hours = (s) => (Number(s || 0) / 3600).toFixed(1);
  const minutes = (s) => Math.round(Number(s || 0) / 60);
  const planNames = { monthly: 'ماهانه', quarterly: 'سه‌ماهه', yearly: 'سالانه' };

  function showDenied(msg) {
    $('stats-auth-error').textContent = msg;
    $('stats-back-auth').onclick = () => { window.location.href = 'admin.html'; };
  }

  function renderBars(targetId, labelsId, data, valueKey, formatter) {
    const target = $(targetId), labels = $(labelsId);
    target.innerHTML = ''; labels.innerHTML = '';
    const values = data.map(x => Number(x[valueKey] || 0));
    const max = Math.max(...values, 1);
    data.forEach((item, i) => {
      const wrap = document.createElement('div');
      wrap.className = 'bar-col';
      const bar = document.createElement('div');
      bar.className = 'bar';
      bar.style.height = `${Math.max(4, (values[i] / max) * 100)}%`;
      bar.title = `${dateFa(item.day)}: ${formatter(values[i])}`;
      wrap.appendChild(bar);
      target.appendChild(wrap);
      if (i % 3 === 0 || i === data.length - 1) {
        const label = document.createElement('span');
        label.textContent = dateFa(item.day);
        labels.appendChild(label);
      } else {
        labels.appendChild(document.createElement('span'));
      }
    });
  }

  function renderPlans(items) {
    const el = $('plan-list');
    if (!items.length) { el.innerHTML = '<div class="stats-empty">هنوز پرداخت موفقی ثبت نشده است.</div>'; return; }
    const max = Math.max(...items.map(p => Number(p.count || 0)), 1);
    el.innerHTML = items.map(p => `
      <div class="plan-row">
        <div class="plan-row-head"><strong>${esc(planNames[p.planId] || p.planId)}</strong><span>${fa(p.count)} خرید</span></div>
        <div class="plan-track"><div class="plan-fill" style="width:${(Number(p.count || 0)/max)*100}%"></div></div>
        <small>${money(p.revenue)} ریال درآمد</small>
      </div>`).join('');
  }

  function renderTopUsers(items) {
    const tbody = $('top-users-tbody');
    tbody.innerHTML = items.map(u => `<tr><td><strong>${esc(u.name)}</strong><small>${esc(u.email)}</small></td><td>${fa(u.focusSessions)}</td><td>${fa(minutes(u.focusSeconds))} دقیقه</td></tr>`).join('') || '<tr><td colspan="3">داده‌ای وجود ندارد.</td></tr>';
  }

  function renderDaily(items) {
    $('daily-tbody').innerHTML = items.map(d => `<tr><td>${dateFa(d.day)}</td><td>${fa(d.registrations)}</td><td>${fa(d.sessions)}</td><td>${fa(minutes(d.focusSeconds))} دقیقه</td><td>${fa(d.paidPayments)}</td><td>${money(d.revenue)} ریال</td></tr>`).join('');
  }

  async function boot() {
    if (!FocusAuth.isLoggedIn()) return showDenied('ابتدا با حساب ادمین وارد شوید.');
    try {
      const me = await FocusAPI.auth.me();
      if (!(me.user?.isAdmin === true || me.user?.role === 'admin')) return showDenied('این حساب دسترسی ادمین ندارد.');
      $('stats-auth').classList.add('d-none');
      $('stats-app').classList.remove('d-none');
      $('stats-welcome').textContent = ' — ' + (me.user.name || 'Admin');
      await load();
    } catch (err) { showDenied(err.message || 'دسترسی رد شد.'); }
  }

  async function load() {
    const data = await FocusAPI.admin.statistics();
    const o = data.overview;
    $('sum-users').textContent = fa(o.totalUsers);
    $('sum-new-users').textContent = fa(o.newUsers30d);
    $('sum-vip').textContent = fa(o.activeVip);
    $('sum-vip-rate').textContent = `${o.vipConversionPercent.toLocaleString('fa-IR')}٪`;
    $('sum-focus-sessions').textContent = fa(o.totalFocusSessions);
    $('sum-focus-hours').textContent = hours(o.totalFocusSeconds);
    $('sum-avg-focus').textContent = fa(minutes(o.avgFocusSeconds));
    $('sum-revenue').textContent = money(o.totalRevenue);
    $('sum-sessions').textContent = fa(o.totalFocusSessions);
    $('sum-paid').textContent = fa(o.paidPayments);
    $('sum-pending').textContent = fa(o.pendingPayments);
    renderBars('focus-bars', 'focus-labels', data.daily, 'focusSeconds', minutes);
    renderBars('revenue-bars', 'revenue-labels', data.daily, 'revenue', money);
    renderPlans(data.planDistribution || []);
    renderTopUsers(data.topUsers || []);
    renderDaily(data.daily || []);
  }

  $('stats-refresh').addEventListener('click', async () => {
    const btn = $('stats-refresh'); btn.disabled = true;
    try { await load(); } catch (e) { alert(e.message || 'خطا در دریافت آمار'); }
    btn.disabled = false;
  });
  $('stats-back').addEventListener('click', () => { window.location.href = 'admin.html'; });
  boot();
})();
