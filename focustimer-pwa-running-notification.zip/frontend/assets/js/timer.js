$(function () {

    let timerInterval = null;

    let hasStarted = false;

    let focusTime = 25;

    let breakTime = 5;

    let isFocusing = true;

    let remaining = focusTime * 60;

    let currentEndTime = null; // ms epoch, mirrors the server's "endTime"; null while paused

    // VIP Focus Plan is transient by design: it controls one planned run and
    // is not stored as the normal timer setting.
    let vipPlanActive = false;
    let vipPlanCycles = 2;
    let vipPlanCompletedFocus = 0;
    let vipPlanFinishAfterBreak = false;
    let vipPlanLongBreak = 20;

    $("#focus-input").val(focusTime);
    $("#break-input").val(breakTime);

    /* -------------------- syncing with the backend --------------------
       We only push settings to the server at meaningful transitions
       (start/pause/reset/mode-switch/session-complete) and debounce the
       two number inputs, never on every 1s tick of the countdown itself.
    -------------------------------------------------------------------- */

    function debounce(fn, wait) {

        let t;

        return function (...args) {

            clearTimeout(t);

            t = setTimeout(() => fn.apply(this, args), wait);
        };
    }

    function syncSettings() {

        FocusAPI.settings.update({

            focusTime: focusTime,
            breakTime: breakTime,
            isFocusing: isFocusing,
            remaining: remaining,
            endTime: currentEndTime,
            timerRunning: !!timerInterval

        }).catch(err => console.error("Could not save timer settings:", err.message));
    }

    const syncSettingsDebounced = debounce(syncSettings, 600);

    function formatTime(seconds) {

        const m = Math.floor(seconds / 60);
        const s = seconds % 60;

        return (
            String(m).padStart(2, "0") +
            ":" +
            String(s).padStart(2, "0")
        );
    }

    function sendToSW(message){

        if(navigator.serviceWorker && navigator.serviceWorker.controller){

            navigator.serviceWorker.controller.postMessage(message);

        }
    }

    function updateRunningNotification() {

        // Android/PWA: keep a persistent timer notification visible while the
        // timer is running. The service worker owns the actual notification.
        sendToSW({
            type: "POMODORO_RUNNING",
            mode: isFocusing ? "focus" : "break",
            remaining: remaining,
            total: isFocusing ? focusTime * 60 : breakTime * 60,
            endTime: currentEndTime
        });
    }

    function clearRunningNotification() {
        sendToSW({ type: "POMODORO_STOPPED" });
    }

    function updateTimer() {

        $("#timer").text(
            formatTime(remaining)
        );
    }

    function updateUI() {

        if (isFocusing) {

            $("#status")
                .text("Focus Session");

            $("#session-icon")
                .attr(
                    "class",
                    "fas fa-brain"
                );

        } else {

            $("#status")
                .text("Break Time");

            $("#session-icon")
                .attr(
                    "class",
                    "fas fa-mug-hot"
                );
        }

        updateTimer();
        updateMiniPlayer();
    }

    function notifyUser() {

        if (
            typeof Notification !== "undefined" &&
            Notification.permission === "granted"
        ) {

            new Notification(
                "FocusTimer 🔔",
                {
                    body: isFocusing
                        ? "زمان تمرکز تمام شد. وقت استراحت است."
                        : "زمان استراحت تمام شد. وقت تمرکز دوباره است."
                }
            );
        }
    }

    function playAlarm() {

        const audio = new Audio("assets/audio/alarm.mp3");

        audio.volume = 0.8;
        audio.play().catch(() => {
            // Fallback bell using browser audio if the file is unavailable
            try {
                const ctx = new (window.AudioContext || window.webkitAudioContext)();
                const osc = ctx.createOscillator();
                const gain = ctx.createGain();
                osc.frequency.value = 880;
                gain.gain.value = 0.15;
                osc.connect(gain);
                gain.connect(ctx.destination);
                osc.start();
                setTimeout(() => {
                    osc.stop();
                    ctx.close();
                }, 500);
            } catch (e) {}
        });
    }

    function requestTimerNotificationPermission() {
        if ("Notification" in window && Notification.permission === "default") {
            Notification.requestPermission().catch(() => {});
        }
    }

    function pauseTimer() {

        clearInterval(timerInterval);

        timerInterval = null;
        currentEndTime = null;
        clearRunningNotification();

        $("#stop-time")
            .addClass("d-none");

        $("#start-time")
            .removeClass("d-none");

        $("#mini-play i")
            .removeClass("fa-pause")
            .addClass("fa-play");

        syncSettings();
    }

    function updateToggleButton() {

        const icon = $("#toggle-mode i");

        if (hasStarted) {

            // نقش Reset
            icon.removeClass();
            icon.addClass("fas fa-rotate-left");

        } else {

            // نقش Toggle
            icon.removeClass();
            icon.addClass("fas fa-sync-alt");
        }
    }

    function startTimer() {

        requestTimerNotificationPermission();

        if (typeof window.isCurrentThemeUsable === "function" && !window.isCurrentThemeUsable()) {
            if (typeof window.openVipRequirementPrompt === "function") {
                window.openVipRequirementPrompt("برای شروع تایمر روی این تم، نیاز به VIP دارید ⭐");
            }
            return;
        }

        currentEndTime = Date.now() + remaining * 1000;

        if (timerInterval) return;

        hasStarted = true;

        updateToggleButton();

        $("#start-time")
            .addClass("d-none");

        $("#stop-time")
            .removeClass("d-none");

        syncSettings();
        updateRunningNotification();

        timerInterval = setInterval(() => {

            remaining--;

            updateTimer();
            updateMiniPlayer();

            if (remaining > 0 && remaining % 15 === 0) {
                updateRunningNotification();
            }

            if (remaining <= 0) {

                // If the VIP plan has just completed its final break, stop
                // instead of starting another focus session.
                const finishingVipPlan = vipPlanActive && !isFocusing && vipPlanFinishAfterBreak;

                playAlarm();

                sendToSW({
                    type: "POMODORO_FINISHED",
                    mode: isFocusing ? "focus" : "break"
                });

                // the session that just ended, logged for /sessions/stats
                FocusAPI.sessions
                    .log(isFocusing ? "focus" : "break", isFocusing ? focusTime * 60 : breakTime * 60)
                    .catch(err => console.error("Could not log session:", err.message));

                if (vipPlanActive && isFocusing) {
                    vipPlanCompletedFocus += 1;
                    vipPlanFinishAfterBreak = vipPlanCompletedFocus >= vipPlanCycles;
                }

                isFocusing = !isFocusing;

                if (!isFocusing && vipPlanActive && vipPlanFinishAfterBreak) {
                    remaining = vipPlanLongBreak * 60;
                } else {
                    remaining = isFocusing ? focusTime * 60 : breakTime * 60;
                }

                currentEndTime = Date.now() + remaining * 1000;
                updateRunningNotification();

                notifyUser();

                syncSettings();

                updateUI();

                showNotification(
                    isFocusing ? "Focus Finished" : "Break Finished",
                    isFocusing ? "Time for a break ☕" : (vipPlanFinishAfterBreak ? "استراحت پایانی VIP" : "Back to focus 💻")
                );

                if (finishingVipPlan) {
                    clearInterval(timerInterval);
                    timerInterval = null;
                    currentEndTime = null;
                    clearRunningNotification();
                    hasStarted = false;
                    vipPlanActive = false;
                    vipPlanFinishAfterBreak = false;
                    vipPlanCompletedFocus = 0;
                    remaining = focusTime * 60;
                    isFocusing = true;

                    $("#stop-time").addClass("d-none");
                    $("#start-time").removeClass("d-none");
                    $("#mini-play i").removeClass("fa-pause").addClass("fa-play");
                    updateToggleButton();
                    updateUI();
                    syncSettings();

                    showNotification("VIP Focus Plan", "برنامه VIP با موفقیت تمام شد ⭐");
                }
            }

        }, 1000);

        $("#mini-play i")
            .removeClass("fa-play")
            .addClass("fa-pause");
    }


    function resetTimer() {

        pauseTimer();

        hasStarted = false;

        updateToggleButton();

        remaining =
            isFocusing
                ? focusTime * 60
                : breakTime * 60;

        syncSettings();

        updateTimer();
        updateMiniPlayer();
    }

    $("#start-time").on(
        "click",
        startTimer
    );

    $("#stop-time").on(
        "click",
        pauseTimer
    );

    $("#reset").on(
        "click",
        resetTimer
    );

    $("#toggle-mode").on("click", () => {

        if (hasStarted) {

            pauseTimer();

            remaining =
                isFocusing
                    ? focusTime * 60
                    : breakTime * 60;

            hasStarted = false;

            updateToggleButton();

            syncSettings();

            updateUI();

            return;
        }

        isFocusing = !isFocusing;

        remaining =
            isFocusing
                ? focusTime * 60
                : breakTime * 60;

        syncSettings();

        updateUI();
    });

    $("#focus-input").on(
        "input",
        function () {

            focusTime =
                parseInt(
                    $(this).val()
                ) || 25;

            if (
                isFocusing &&
                !timerInterval
            ) {

                remaining =
                    focusTime * 60;

                updateTimer();
                updateMiniPlayer();
            }

            syncSettingsDebounced();
        }
    );

    $("#break-input").on(
        "input",
        function () {

            breakTime =
                parseInt(
                    $(this).val()
                ) || 5;

            if (
                !isFocusing &&
                !timerInterval
            ) {

                remaining =
                    breakTime * 60;

                updateTimer();
                updateMiniPlayer();
            }

            syncSettingsDebounced();
        }
    );


    if (
        "Notification" in window
    ) {
        Notification.requestPermission();
    }


    function enterCompactMode(){

        $("main").addClass("compact");
        $("header").addClass("compact");

        $("#music-panel").addClass("compact");
        $("#music-overlay").addClass("compact");
        $("#music-mini-player").removeClass("show");
        $("#mini-player").addClass("show");

    }

    function exitCompactMode(){

        $("main").removeClass("compact");
        $("header").removeClass("compact");

        $("#music-panel").removeClass("compact");
        $("#music-overlay").removeClass("compact");

        if(typeof currentSong !== "undefined" && currentSong !== -1){
            $("#music-mini-player").addClass("show");
        }

        $("#mini-player").removeClass("show");

    }

    $("#compact-mode-btn").on("click", enterCompactMode);

    $("#close-mini").on("click", exitCompactMode);

    $(".mini-center").on("click", exitCompactMode);

    $(document).on("keydown", function (e) {

        if (
            e.key === "Escape" &&
            $("#mini-player").hasClass("show")
        ) {
            exitCompactMode();
        }
    });

    function updateMiniPlayer(){

        $("#mini-time").text(formatTime(remaining));

        $("#mini-mode").text(
            isFocusing
                ? "Focus"
                : "Break"
        );

        $("#mini-mode-icon").attr(
            "class",
            isFocusing ? "fas fa-brain" : "fas fa-mug-hot"
        );

        const totalSeconds =
            isFocusing
                ? focusTime * 60
                : breakTime * 60;

        const elapsed =
            totalSeconds - remaining;

        const percent =
            (elapsed / totalSeconds) * 100;

        $("#mini-progress").css(
            "width",
            percent + "%"
        );

    }

    $("#mini-play").on("click",function(){

        if(timerInterval){

            pauseTimer();

        }else{

            startTimer();

        }

    });

    $("#mini-toggle").on("click", function () {

        $("#toggle-mode").trigger("click");

    });


    function showNotification(title, body){

        if(
            typeof Notification === "undefined" ||
            Notification.permission !== "granted"
        ) return;

        new Notification(title, {

            body: body,

            icon: "./assets/icons/icon-192.png"

        });

    }

    let deferredPrompt = null;

    const installBtn = document.getElementById("install-btn");

    window.addEventListener("beforeinstallprompt", (e) => {

        e.preventDefault();

        deferredPrompt = e;

        if (installBtn) installBtn.style.display = "block";

    });

    if (installBtn) {

        installBtn.addEventListener("click", async () => {

            if (!deferredPrompt) return;

            deferredPrompt.prompt();

            const { outcome } = await deferredPrompt.userChoice;

            console.log(outcome);

            deferredPrompt = null;

            installBtn.style.display = "none";

        });
    }

    window.addEventListener("appinstalled", () => {

        if (installBtn) installBtn.style.display = "none";

        console.log("App Installed");

    });


    // Public controller used by vip.js. The backend remains the authority
    // for VIP access; this only applies a plan to the local timer.
    window.VIPTimerController = {
        isRunning: () => !!timerInterval,
        applyPlan({ focus, break: breakMinutes, cycles, longBreak }) {
            if (timerInterval) {
                throw new Error("تایمر در حال اجراست. ابتدا آن را متوقف کن.");
            }

            focusTime = Number(focus);
            breakTime = Number(breakMinutes);
            vipPlanCycles = Number(cycles);
            vipPlanLongBreak = Number(longBreak);

            if (!Number.isFinite(focusTime) || !Number.isFinite(breakTime) ||
                !Number.isInteger(vipPlanCycles) || !Number.isInteger(vipPlanLongBreak) ||
                focusTime < 1 || focusTime > 180 || breakTime < 1 || breakTime > 60 ||
                vipPlanCycles < 2 || vipPlanCycles > 6 || vipPlanLongBreak < 1 || vipPlanLongBreak > 30) {
                throw new Error("تنظیمات Focus Plan معتبر نیست.");
            }

            vipPlanActive = true;
            vipPlanCompletedFocus = 0;
            vipPlanFinishAfterBreak = false;
            isFocusing = true;
            hasStarted = false;
            currentEndTime = null;
            remaining = focusTime * 60;

            $("#focus-input").val(focusTime);
            $("#break-input").val(breakTime);
            updateToggleButton();
            updateUI();
            syncSettings();
        },
        cancelPlan() {
            vipPlanActive = false;
            vipPlanCompletedFocus = 0;
            vipPlanFinishAfterBreak = false;
        }
    };

    /* ===================================================================
       Initialize — waits for login (see api.js / auth-ui.js). Loads the
       saved settings from the server and resumes a running session if
       one was left going (same idea as the old localStorage restoreTimer).
    =================================================================== */

    async function initTimer(){

        try{

            const result = await FocusAPI.settings.get();

            const s = result.settings;

            focusTime = s.focusTime;
            breakTime = s.breakTime;
            isFocusing = s.isFocusing;
            remaining = s.remaining;

            $("#focus-input").val(focusTime);
            $("#break-input").val(breakTime);

            if (s.timerRunning && s.endTime) {

                const diff = Math.floor((s.endTime - Date.now()) / 1000);

                if (diff > 0) {

                    remaining = diff;

                    updateTimer();

                    startTimer();

                } else {

                    // the session finished while we were away — start the
                    // current mode fresh instead of showing a stuck 0:00
                    remaining = isFocusing ? focusTime * 60 : breakTime * 60;

                    syncSettings();
                }
            }

            updateUI();

        }catch(err){

            console.error("Could not load timer settings:", err.message);

            updateUI();
        }
    }

    document.addEventListener("focus:authenticated", initTimer);

    document.addEventListener("focus:loggedout", function(){

        // local-only reset — no point syncing settings once logged out
        clearInterval(timerInterval);

        timerInterval = null;
        currentEndTime = null;
        hasStarted = false;

        isFocusing = true;
        focusTime = 25;
        breakTime = 5;
        remaining = focusTime * 60;

        $("#focus-input").val(focusTime);
        $("#break-input").val(breakTime);

        $("#stop-time").addClass("d-none");
        $("#start-time").removeClass("d-none");

        updateToggleButton();
        updateUI();
    });

});
