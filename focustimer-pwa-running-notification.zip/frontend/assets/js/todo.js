$(function () {
    const todoBtn = $("#todo-btn");
    const panel = $("#todo-panel");
    const overlay = $("#todo-overlay");
    const input = $("#task-input");
    const list = $("#todo-list");
    const counter = $("#task-counter");
    const clearCompleted = $("#clear-completed");
    const vipTools = $("#vip-todo-tools");
    const categoryInput = $("#task-category");
    const prioritySelect = $("#task-priority");
    const filterSelect = $("#todo-filter");
    const vipHint = $("#todo-vip-hint");

    let tasks = [];
    let isVip = false;
    let categories = [];
    const FREE_TASK_LIMIT = 10;

    function priorityLabel(priority) {
        if (Number(priority) === 2) return "Urgent";
        if (Number(priority) === 1) return "High";
        return "Normal";
    }

    function updateCounter() {
        counter.text(isVip ? `${tasks.length} Tasks · VIP` : `${tasks.length}/${FREE_TASK_LIMIT} Tasks`);

        vipHint.toggleClass("show", isVip);
        if (!isVip && tasks.length >= FREE_TASK_LIMIT) {
            vipHint.text("به سقف ۱۰ کار نسخه رایگان رسیدی. با VIP این محدودیت حذف می‌شود.");
        } else if (isVip) {
            vipHint.text("اولویت، دسته‌بندی و فیلتر برای حساب VIP فعال است ⭐");
        } else {
            vipHint.text("");
        }
    }

    function getFilteredTasks() {
        const filter = filterSelect.val() || "all";
        if (filter === "active") return tasks.filter(task => !task.done);
        if (filter === "completed") return tasks.filter(task => task.done);
        if (filter === "urgent") return tasks.filter(task => Number(task.priority) === 2);
        return tasks;
    }

    function renderTasks() {
        list.empty();
        const visibleTasks = getFilteredTasks();

        if (!visibleTasks.length) {
            list.append('<div class="todo-empty">کاری برای نمایش وجود ندارد.</div>');
            updateCounter();
            return;
        }

        visibleTasks.forEach(task => {
            const priority = Number(task.priority) || 0;
            const category = task.category || "General";
            const priorityClass = priority === 2 ? "priority-urgent" : priority === 1 ? "priority-high" : "priority-normal";
            const item = $("<div class='todo-item'></div>")
                .toggleClass("done", !!task.done)
                .toggleClass("vip-task-item", isVip);

            const taskLeft = $("<div class='task-left'></div>");
            const label = $("<label class='task-check-wrapper'></label>");
            const checkbox = $("<input type='checkbox' class='task-check'>").prop("checked", !!task.done);
            const checkmark = $("<span class='checkmark'></span>");
            const text = $("<span class='task-text'></span>").text(task.text);

            label.append(checkbox, checkmark);
            taskLeft.append(label, text);

            if (isVip) {
                const meta = $("<div class='todo-meta'></div>");
                meta.append($(`<span class='todo-priority ${priorityClass}'></span>`).text(priorityLabel(priority)));
                meta.append($("<span class='todo-category'></span>").text(category));
                taskLeft.append(meta);
            }

            const actions = $("<div class='todo-actions'></div>");
            const deleteButton = $("<button class='delete-task' type='button' aria-label='Delete task'></button>")
                .append('<i class="fa-solid fa-trash"></i>');
            actions.append(deleteButton);

            item.append(taskLeft, actions);

            checkbox.on("change", async function () {
                const checked = this.checked;
                try {
                    await FocusAPI.todos.update(task.id, { done: checked });
                    task.done = checked;
                    renderTasks();
                } catch (err) {
                    checkbox.prop("checked", !checked);
                    console.error("Could not update task:", err.message);
                }
            });

            deleteButton.on("click", async function () {
                try {
                    await FocusAPI.todos.remove(task.id);
                    tasks = tasks.filter(t => t.id !== task.id);
                    renderTasks();
                } catch (err) {
                    console.error("Could not delete task:", err.message);
                }
            });

            list.append(item);
        });

        updateCounter();
    }

    async function addTask() {
        const text = input.val().trim();
        if (!text) return;

        if (!isVip && tasks.length >= FREE_TASK_LIMIT) {
            alert("نسخه رایگان حداکثر ۱۰ کار دارد. برای حذف محدودیت، VIP را فعال کن.");
            return;
        }

        const options = isVip ? {
            category: categoryInput.val().trim() || "General",
            priority: Number(prioritySelect.val()) || 0,
        } : {};

        input.val("");

        try {
            const result = await FocusAPI.todos.create(text, options);
            tasks.push(result.todo);
            renderTasks();
        } catch (err) {
            input.val(text);
            alert(err.message || "خطا در ساختن کار");
        }
    }

    async function initTodos(detailUser) {
        try {
            isVip = !!detailUser?.vip?.active;
            if (isVip) {
                try {
                    const result = await FocusAPI.vip.todoOptions();
                    categories = result.todo?.categories || [];
                    categoryInput.val(categories[0] || "General");
                } catch (err) {
                    console.warn("Could not load VIP To-Do options:", err.message);
                }
            } else {
                categories = [];
            }

            vipTools.toggleClass("show", isVip);
            filterSelect.toggleClass("vip-filter", isVip);

            const result = await FocusAPI.todos.list();
            tasks = result.todos || [];
            isVip = !!result.vip;
            renderTasks();
        } catch (err) {
            tasks = [];
            renderTasks();
            console.error("Could not load tasks:", err.message);
        }
    }

    $("#add-task").on("click", addTask);
    input.on("keypress", function (e) {
        if (e.which === 13) addTask();
    });

    clearCompleted.on("click", async function () {
        try {
            await FocusAPI.todos.clearCompleted();
            tasks = tasks.filter(task => !task.done);
            renderTasks();
        } catch (err) {
            console.error("Could not clear completed tasks:", err.message);
        }
    });

    filterSelect.on("change", renderTasks);

    todoBtn.on("click", function () {
        panel.addClass("show");
        overlay.addClass("show");
    });

    $("#close-todo").on("click", function () {
        panel.removeClass("show");
        overlay.removeClass("show");
    });

    overlay.on("click", function () {
        panel.removeClass("show");
        overlay.removeClass("show");
    });

    document.addEventListener("focus:authenticated", function (event) {
        initTodos(event.detail?.user || {});
    });

    document.addEventListener("focus:loggedout", function () {
        tasks = [];
        isVip = false;
        vipTools.removeClass("show");
        renderTasks();
        panel.removeClass("show");
        overlay.removeClass("show");
    });
});
