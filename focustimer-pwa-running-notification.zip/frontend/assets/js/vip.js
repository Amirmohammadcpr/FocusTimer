/* ===================================================================
   VIP UI — status badge + VIP panel.
   This file handles presentation only. Backend remains the authority
   for whether a user is actually VIP.
=================================================================== */

$(function () {

    // Shared VIP state for local frontend music/theme gates.
    window.focusTimerVipActive = false;

    const paymentResult = new URLSearchParams(window.location.search).get("payment");
    if (paymentResult === "success") {
        setTimeout(() => alert("پرداخت با موفقیت تأیید شد و اشتراک VIP فعال شد."), 100);
    } else if (paymentResult === "cancelled") {
        setTimeout(() => alert("پرداخت لغو شد."), 100);
    } else if (paymentResult === "failed") {
        setTimeout(() => alert("پرداخت تأیید نشد."), 100);
    }

    const vipBtn = $("#vip-btn");
    const vipOverlay = $("#vip-overlay");
    const vipPanel = $("#vip-panel");
    const closeVip = $("#close-vip");

    const vipHeaderLabel = $("#vip-header-label");
    const vipBadge = $("#user-vip-badge");
    const statusCard = $("#vip-status-card");
    const statusTitle = $("#vip-status-title");
    const statusDetail = $("#vip-status-detail");
    const actionArea = $("#vip-action-area");
    const subscriptionSection = $("#vip-subscription-section");
    const subscriptionLoading = $("#vip-subscription-loading");
    const subscriptionError = $("#vip-subscription-error");
    const plansContainer = $("#vip-plans");
    const currentSubscription = $("#vip-current-subscription");
    const subscriptionManagement = $("#vip-subscription-management");
    const subscriptionPlan = $("#vip-subscription-plan");
    const subscriptionDates = $("#vip-subscription-dates");
    const subscriptionRenewal = $("#vip-subscription-renewal");
    const cancelRenewalBtn = $("#vip-cancel-renewal");
    const paymentHistory = $("#vip-payment-history");
    const paymentHistoryLoading = $("#vip-payment-history-loading");
    const paymentHistoryError = $("#vip-payment-history-error");
    const subscriptionHistory = $("#vip-subscription-history");
    const statsBtn = $("#vip-stats-btn");
    const statsSection = $("#vip-stats-section");
    const statsLoading = $("#vip-stats-loading");
    const statsError = $("#vip-stats-error");
    const statsContent = $("#vip-stats-content");
    const dailyList = $("#vip-daily-list");

    const timerSection = $("#vip-timer-section");
    const timerLoading = $("#vip-timer-loading");
    const timerError = $("#vip-timer-error");
    const timerContent = $("#vip-timer-content");
    const timerPresets = $("#vip-timer-presets");
    const cycleSelect = $("#vip-cycle-select");
    const longBreakSelect = $("#vip-long-break-select");
    const planToggle = $("#vip-plan-toggle");

    function formatMinutes(seconds) {
        const minutes = Math.round((Number(seconds) || 0) / 60);
        return `${minutes} دقیقه`;
    }

    function formatDay(value) {
        if (!value) return "—";
        const date = new Date(`${value}T00:00:00`);
        if (Number.isNaN(date.getTime())) return value;
        return new Intl.DateTimeFormat("fa-IR", {
            month: "short",
            day: "numeric"
        }).format(date);
    }

    function resetStats() {
        statsSection.addClass("d-none");
        statsLoading.addClass("d-none");
        statsError.addClass("d-none").text("");
        statsContent.addClass("d-none");
        dailyList.empty();
    }

    function renderStats(stats) {
        $("#vip-stat-focus-sessions").text(Number(stats.focus_sessions) || 0);
        $("#vip-stat-focus-time").text(formatMinutes(stats.total_focus_seconds));
        $("#vip-stat-average").text(formatMinutes(stats.average_focus_seconds));
        $("#vip-stat-best-day").text(stats.bestDay ? `${formatDay(stats.bestDay.day)} · ${formatMinutes(stats.bestDay.focus_seconds)}` : "—");

        dailyList.empty();
        const days = Array.isArray(stats.daily) ? stats.daily : [];
        if (!days.length) {
            dailyList.append('<div class="vip-daily-empty">هنوز جلسه‌ای برای نمایش وجود ندارد.</div>');
        } else {
            days.forEach((day) => {
                const minutes = Math.round((Number(day.focus_seconds) || 0) / 60);
                const width = Math.max(4, Math.min(100, minutes));
                const row = $(`
                    <div class="vip-daily-row">
                        <span class="vip-daily-day">${formatDay(day.day)}</span>
                        <div class="vip-daily-bar"><span style="width:${width}%"></span></div>
                        <span class="vip-daily-value">${minutes}د</span>
                    </div>
                `);
                dailyList.append(row);
            });
        }

        statsContent.removeClass("d-none");
    }

    async function loadAdvancedStats() {
        if (!currentVip || !currentVip.active) {
            return;
        }

        statsSection.removeClass("d-none");
        statsLoading.removeClass("d-none");
        statsError.addClass("d-none").text("");
        statsContent.addClass("d-none");

        try {
            const result = await FocusAPI.vip.advancedStatistics();
            renderStats(result.stats || {});
        } catch (err) {
            statsError.text(err.message || "خطا در دریافت آمار پیشرفته").removeClass("d-none");
        } finally {
            statsLoading.addClass("d-none");
        }
    }

    let timerOptionsCache = null;

    function resetTimerOptions() {
        timerSection.addClass("d-none");
        timerLoading.addClass("d-none");
        timerError.addClass("d-none").text("");
        timerContent.addClass("d-none");
        timerPresets.empty();
        cycleSelect.empty();
        longBreakSelect.empty();
        planToggle.prop("checked", false);
    }

    function renderTimerOptions(timer) {
        timerOptionsCache = timer || { presets: [], cycleOptions: [], longBreakOptions: [] };
        timerPresets.empty();
        cycleSelect.empty();
        longBreakSelect.empty();

        (timerOptionsCache.presets || []).forEach((preset, index) => {
            const btn = $(`
                <button type="button" class="vip-timer-preset ${index === 0 ? "active" : ""}">
                    <strong>${preset.label}</strong>
                    <small>${preset.focus} / ${preset.break} دقیقه</small>
                </button>
            `);
            btn.on("click", function () {
                $(".vip-timer-preset").removeClass("active");
                btn.addClass("active");
                $("#focus-input").val(preset.focus);
                $("#break-input").val(preset.break);
            });
            timerPresets.append(btn);
        });

        (timerOptionsCache.cycleOptions || []).forEach((cycles) => {
            cycleSelect.append(new Option(`${cycles} چرخه`, cycles));
        });
        (timerOptionsCache.longBreakOptions || []).forEach((minutes) => {
            longBreakSelect.append(new Option(`${minutes} دقیقه`, minutes));
        });

        timerSection.removeClass("d-none");
        timerContent.removeClass("d-none");
    }

    async function loadTimerOptions() {
        if (!currentVip || !currentVip.active) {
            resetTimerOptions();
            return;
        }

        timerSection.removeClass("d-none");
        timerLoading.removeClass("d-none");
        timerError.addClass("d-none").text("");
        timerContent.addClass("d-none");

        try {
            const result = await FocusAPI.vip.timerOptions();
            renderTimerOptions(result.timer);
        } catch (err) {
            timerError.text(err.message || "خطا در دریافت تنظیمات تایمر VIP").removeClass("d-none");
        } finally {
            timerLoading.addClass("d-none");
        }
    }

    function applyVipTimerPlan() {
        if (!currentVip || !currentVip.active) {
            alert("این قابلیت مخصوص کاربران VIP است.");
            return;
        }

        if (!window.VIPTimerController) {
            alert("کنترلر تایمر در دسترس نیست. صفحه را دوباره باز کن.");
            return;
        }

        try {
            const preset = timerOptionsCache?.presets?.find((item) =>
                Number(item.focus) === Number($("#focus-input").val()) &&
                Number(item.break) === Number($("#break-input").val())
            );

            const focus = Number($("#focus-input").val());
            const breakMinutes = Number($("#break-input").val());
            const cycles = Number(cycleSelect.val());
            const longBreak = Number(longBreakSelect.val());

            if (window.VIPTimerController.isRunning()) {
                throw new Error("تایمر در حال اجراست. ابتدا آن را متوقف کن.");
            }

            window.VIPTimerController.applyPlan({
                focus: preset ? preset.focus : focus,
                break: preset ? preset.break : breakMinutes,
                cycles,
                longBreak,
            });

            planToggle.prop("checked", true);
            alert(`برنامه VIP فعال شد: ${cycles} چرخه ⭐`);
        } catch (err) {
            planToggle.prop("checked", false);
            alert(err.message || "خطا در اعمال برنامه VIP");
        }
    }

    let currentVip = null;
    let statusRequest = null;

    function formatDate(value) {
        if (!value) return "";

        const date = new Date(value);
        if (Number.isNaN(date.getTime())) return value;

        return new Intl.DateTimeFormat("fa-IR", {
            dateStyle: "medium"
        }).format(date);
    }

    function paymentStatusLabel(status) {
        const labels = {
            paid: "موفق",
            pending: "در انتظار",
            failed: "ناموفق",
        };
        return labels[status] || status || "—";
    }

    function renderPaymentHistory(payments) {
        paymentHistory.empty();
        const rows = Array.isArray(payments) ? payments : [];
        if (!rows.length) {
            paymentHistory.html('<div class="vip-history-empty">هنوز پرداختی ثبت نشده است.</div>');
            return;
        }

        rows.slice(0, 20).forEach((payment) => {
            const row = $(`
                <div class="vip-payment-row">
                    <div>
                        <strong>${payment.plan_id}</strong>
                        <small>${formatDate(payment.created_at)}</small>
                    </div>
                    <div class="vip-payment-meta">
                        <span>${payment.amount == null ? "—" : payment.amount + " " + (payment.currency || "")}</span>
                        <span class="vip-payment-status ${payment.status}">${paymentStatusLabel(payment.status)}</span>
                    </div>
                </div>
            `);
            paymentHistory.append(row);
        });
    }

    async function loadPaymentHistory() {
        if (!FocusAuth.isLoggedIn()) {
            paymentHistory.empty();
            return;
        }

        paymentHistoryLoading.removeClass("d-none");
        paymentHistoryError.addClass("d-none").text("");
        try {
            const result = await FocusAPI.payments.history();
            renderPaymentHistory(result.payments || []);
        } catch (err) {
            paymentHistoryError.text(err.message || "خطا در دریافت تاریخچه پرداخت").removeClass("d-none");
        } finally {
            paymentHistoryLoading.addClass("d-none");
        }
    }


    function renderSubscriptionHistory(history) {
        subscriptionHistory.empty();
        const rows = Array.isArray(history) ? history : [];
        if (!rows.length) {
            subscriptionHistory.html('<div class="vip-history-empty">هنوز سابقه اشتراکی وجود ندارد.</div>');
            return;
        }
        rows.slice(0, 20).forEach((sub) => {
            const status = sub.status === "active" ? "فعال" : sub.status === "cancelled" ? "لغوشده" : sub.status === "expired" ? "منقضی" : sub.status;
            subscriptionHistory.append(`
                <div class="vip-payment-row">
                    <div>
                        <strong>${sub.plan_id}</strong>
                        <small>${formatDate(sub.started_at)} تا ${formatDate(sub.expires_at)}</small>
                    </div>
                    <span class="vip-payment-status ${sub.status}">${status}</span>
                </div>
            `);
        });
    }

    function renderSubscriptionDetails(sub) {
        if (!sub) {
            subscriptionManagement.addClass("d-none");
            currentSubscription.addClass("d-none").text("");
            return;
        }

        currentSubscription
            .removeClass("d-none")
            .text(`اشتراک فعلی: ${sub.plan_id} · تا ${formatDate(sub.expires_at)}`);
        subscriptionManagement.removeClass("d-none");
        subscriptionPlan.text(`اشتراک ${sub.plan_id}`);
        subscriptionDates.text(`${formatDate(sub.started_at)} تا ${formatDate(sub.expires_at)}`);

        if (Number(sub.auto_renew) === 1) {
            subscriptionRenewal.text("تمدید خودکار فعال").removeClass("off");
            cancelRenewalBtn.prop("disabled", false).show();
        } else {
            subscriptionRenewal.text("بدون تمدید خودکار").addClass("off");
            cancelRenewalBtn.hide();
        }
    }

    async function cancelCurrentRenewal() {
        const currentId = cancelRenewalBtn.data("subscription-id");
        if (!currentId) return;

        const confirmed = confirm("تمدید خودکار این اشتراک لغو شود؟ دسترسی VIP تا تاریخ انقضا باقی می‌ماند.");
        if (!confirmed) return;

        cancelRenewalBtn.prop("disabled", true).text("در حال لغو...");
        try {
            await FocusAPI.vip.cancelSubscription(currentId);
            await loadSubscriptions();
            alert("تمدید خودکار لغو شد.");
        } catch (err) {
            alert(err.message || "خطا در لغو تمدید خودکار");
            cancelRenewalBtn.prop("disabled", false).html('<i class="fa-solid fa-calendar-xmark"></i> لغو تمدید خودکار');
        }
    }

    async function loadSubscriptions() {
        if (!FocusAuth.isLoggedIn()) {
            subscriptionSection.addClass("d-none");
            return;
        }

        subscriptionSection.removeClass("d-none");
        subscriptionLoading.removeClass("d-none");
        subscriptionError.addClass("d-none").text("");

        try {
            const [plansResult, subscriptionResult] = await Promise.all([
                FocusAPI.vip.plans(),
                FocusAPI.vip.subscription(),
            ]);

            plansContainer.empty();
            (plansResult.plans || []).forEach((plan) => {
                const priceConfigured = Number(plan.price) > 0;
                const priceText = priceConfigured ? `${Number(plan.price).toLocaleString("fa-IR")} ${plan.currency || "IRR"}` : "قیمت تنظیم نشده";
                const card = $(`
                    <article class="vip-plan-card">
                        <h4>${plan.name}</h4>
                        <p>${plan.days} روز</p>
                        <p>${priceText}</p>
                        <button type="button" class="vip-primary-btn vip-plan-select" data-plan-id="${plan.id}" ${priceConfigured ? "" : "disabled"}>${priceConfigured ? "انتخاب پلن" : "در انتظار تعیین قیمت"}</button>
                    </article>
                `);
                card.find(".vip-plan-select").on("click", async function () {
                    const button = $(this);
                    const oldText = button.text();
                    button.prop("disabled", true).text("در حال ایجاد پرداخت...");
                    try {
                        const created = await FocusAPI.payments.create(plan.id);
                        if (created.mode === "mock") {
                            const proceed = confirm("این نسخه از درگاه آزمایشی استفاده می‌کند و مبلغ واقعی کسر نمی‌شود. پرداخت آزمایشی کامل شود؟");
                            if (proceed) {
                                const completed = await FocusAPI.payments.mockComplete(created.payment.payment_id);
                                renderStatus(completed.vip);
                                await loadSubscriptions();
                                alert("پرداخت آزمایشی موفق بود و VIP فعال شد.");
                            }
                        } else if (created.provider?.paymentUrl) {
                            window.location.href = created.provider.paymentUrl;
                        } else {
                            throw new Error("آدرس درگاه پرداخت دریافت نشد.");
                        }
                    } catch (err) {
                        alert(err.message || "خطا در ایجاد یا تأیید پرداخت");
                    } finally {
                        button.prop("disabled", false).text(oldText);
                    }
                });
                plansContainer.append(card);
            });

            const sub = subscriptionResult.current;
            renderSubscriptionDetails(sub);
            renderSubscriptionHistory(subscriptionResult.history || []);
            if (sub) cancelRenewalBtn.data("subscription-id", sub.id);
            await loadPaymentHistory();
        } catch (err) {
            subscriptionError.text(err.message || "خطا در دریافت اطلاعات اشتراک").removeClass("d-none");
        } finally {
            subscriptionLoading.addClass("d-none");
        }
    }

    function setGuestState() {
        currentVip = null;
        window.focusTimerVipActive = false;
        vipBadge.addClass("d-none");
        vipHeaderLabel.text("VIP");
        statusCard.removeClass("active");
        statusTitle.text("برای استفاده از VIP وارد حساب شو");
        statusDetail.text("بعد از ورود می‌توانی وضعیت اشتراک خودت را ببینی.");
        actionArea.removeClass("active");
        statsBtn.addClass("d-none");
        $("#vip-full-stats-btn").addClass("d-none");
        resetStats();
        resetTimerOptions();
        renderSubscriptionDetails(null);
        paymentHistory.empty();
        subscriptionHistory.empty();
    }

    function renderStatus(vip) {
        currentVip = vip || { active: false };
        window.focusTimerVipActive = !!currentVip.active;

        if (currentVip.active) {
            vipBadge.removeClass("d-none");
            vipHeaderLabel.text("VIP فعال");
            statusCard.addClass("active");
            statusTitle.text("اشتراک VIP فعال است");

            const expiry = formatDate(currentVip.expiresAt);
            statusDetail.text(
                expiry ? `تا ${expiry}` : "اشتراک VIP شما فعال است."
            );

            actionArea.addClass("active");
            statsBtn.removeClass("d-none").off("click").on("click", loadAdvancedStats);
            $("#vip-full-stats-btn").removeClass("d-none").off("click").on("click", function () {
                window.location.href = "vip-statistics.html";
            });
            loadTimerOptions();
            $("#vip-upgrade-btn")
                .prop("disabled", false)
                .html('<i class="fa-solid fa-crown"></i> امکانات VIP')
                .off("click")
                .on("click", loadVipFeatures);

            return;
        }

        vipBadge.addClass("d-none");
        vipHeaderLabel.text("ارتقا به VIP");
        statusCard.removeClass("active");
        statusTitle.text("نسخه رایگان");
        statusDetail.text("برای دسترسی به امکانات ویژه، VIP را فعال کن.");
        actionArea.addClass("active");
        statsBtn.addClass("d-none");
        $("#vip-full-stats-btn").addClass("d-none");
        resetStats();
        resetTimerOptions();

        $("#vip-upgrade-btn")
            .prop("disabled", false)
            .html('<i class="fa-solid fa-gem"></i> مشاهده امکانات VIP')
            .off("click")
            .on("click", loadVipFeatures);
    }

    async function refreshStatus() {
        if (!FocusAuth.isLoggedIn()) {
            setGuestState();
            return;
        }

        if (statusRequest) return statusRequest;

        statusRequest = FocusAPI.vip.status()
            .then((result) => {
                renderStatus(result.vip);
                return result.vip;
            })
            .catch((err) => {
                if (err.status === 401) {
                    setGuestState();
                    return null;
                }

                statusTitle.text("وضعیت VIP در دسترس نیست");
                statusDetail.text(err.message || "خطا در دریافت وضعیت اشتراک");
                return null;
            })
            .finally(() => {
                statusRequest = null;
            });

        return statusRequest;
    }

    async function loadVipFeatures() {
        const btn = $("#vip-upgrade-btn");
        const oldHtml = btn.html();

        btn.prop("disabled", true).html(
            '<i class="fa-solid fa-spinner fa-spin"></i> در حال بررسی...'
        );

        try {
            const result = await FocusAPI.vip.features();

            if (result && result.vip && result.vip.active) {
                renderStatus(result.vip);
                alert("امکانات VIP برای این حساب فعال است.");
            } else {
                alert("این بخش در مرحله پرداخت تکمیل خواهد شد.");
            }
        } catch (err) {
            if (err.status === 403) {
                alert("این قابلیت مخصوص کاربران VIP است.");
            } else {
                alert(err.message || "خطا در بررسی VIP");
            }
        } finally {
            btn.prop("disabled", false).html(oldHtml);
        }
    }

    function openVip() {
        vipOverlay.addClass("show");
        vipPanel.addClass("show");
        refreshStatus();
        loadSubscriptions();
    }

    // song.js uses this when a Free user selects a locked VIP track.
    window.openVipPanel = openVip;

    function closePanel() {
        vipOverlay.removeClass("show");
        vipPanel.removeClass("show");
    }

    $("#vip-stats-refresh").on("click", loadAdvancedStats);
    $("#vip-subscription-refresh").on("click", loadSubscriptions);
    $("#vip-payment-history-refresh").on("click", loadPaymentHistory);
    cancelRenewalBtn.on("click", cancelCurrentRenewal);
    $("#vip-timer-refresh").on("click", loadTimerOptions);
    $("#vip-apply-timer").on("click", applyVipTimerPlan);
    planToggle.on("change", function () {
        if (!this.checked && window.VIPTimerController) {
            window.VIPTimerController.cancelPlan();
        }
    });

    vipBtn.on("click", openVip);
    closeVip.on("click", closePanel);
    vipOverlay.on("click", closePanel);

    $(document).on("keydown", function (e) {
        if (e.key === "Escape") closePanel();
    });

    document.addEventListener("focus:authenticated", function (e) {
        renderStatus(e.detail?.user?.vip || { active: false });
    });

    document.addEventListener("focus:loggedout", function () {
        setGuestState();
        closePanel();
    });

    setGuestState();
});


// Small reusable toast for locked VIP themes.
window.showThemeVipToast = function (message) {
    const el = document.getElementById("theme-vip-toast");
    if (!el) { alert(message); return; }
    el.textContent = message;
    el.classList.add("show");
    clearTimeout(window.__themeVipToastTimer);
    window.__themeVipToastTimer = setTimeout(() => el.classList.remove("show"), 2600);
};
