/* ===================================================================
   FocusTimer API client
   -------------------------------------------------------------------
   Talks to the FocusTimer backend (see /focustimer-backend). Handles
   the JWT token and exposes small, typed helpers so todo.js, timer.js
   and song.js don't need to know about fetch/headers/error handling.

   Production backend: https://api.focustimer.ir/api
=================================================================== */

const API_BASE_URL = (() => {
    const host = window.location.hostname;
    if (host === "localhost" || host === "127.0.0.1" || host === "::1") {
        return "http://localhost:4000/api";
    }
    return "https://api.focustimer.ir/api";
})();

const TOKEN_KEY = "focustimer_token";

/* -------------------- token storage -------------------- */

const FocusAuth = {

    getToken() {
        return localStorage.getItem(TOKEN_KEY);
    },

    setToken(token) {
        localStorage.setItem(TOKEN_KEY, token);
    },

    clearToken() {
        localStorage.removeItem(TOKEN_KEY);
    },

    isLoggedIn() {
        return !!this.getToken();
    }

};

/* -------------------- low level request helper -------------------- */

async function apiRequest(path, { method = "GET", body, auth = true } = {}) {

    const headers = { "Content-Type": "application/json" };

    if (auth) {

        const token = FocusAuth.getToken();

        if (token) headers["Authorization"] = "Bearer " + token;

    }

    let response;

    try {

        response = await fetch(API_BASE_URL + path, {
            method: method,
            headers: headers,
            body: body !== undefined ? JSON.stringify(body) : undefined
        });

    } catch (networkErr) {

        throw new Error("عدم دسترسی به سرور FocusTimer.");

    }

    if (response.status === 204) return null;

    let data = null;

    try {
        data = await response.json();
    } catch (parseErr) {
        // no JSON body, that's fine for some responses
    }

    if (!response.ok) {

        const message = (data && data.error) || ("خطای سرور (" + response.status + ")");

        const err = new Error(message);

        err.status = response.status;

        throw err;
    }

    return data;
}


async function uploadBinary(path, blob, offset, totalBytes) {
    const token = FocusAuth.getToken();
    const headers = {
        "Content-Type": "application/octet-stream",
        "X-Upload-Offset": String(offset),
        "X-Upload-Total": String(totalBytes)
    };
    if (token) headers["Authorization"] = "Bearer " + token;
    let response;
    try {
        response = await fetch(API_BASE_URL + path, { method: "PUT", headers, body: blob });
    } catch (_) {
        throw new Error("عدم دسترسی به سرور هنگام آپلود فایل.");
    }
    let data = null;
    try { data = await response.json(); } catch (_) {}
    if (!response.ok) {
        const err = new Error((data && data.error) || ("خطای آپلود (" + response.status + ")"));
        err.status = response.status;
        throw err;
    }
    return data;
}

async function uploadInChunks({ initPath, initBody, chunkPath, completePath, file, onProgress }) {
    const init = await apiRequest(initPath, { method: "POST", body: initBody });
    const uploadId = init.uploadId;
    const chunkSize = Number(init.chunkSize || 5 * 1024 * 1024);
    let offset = 0;
    while (offset < file.size) {
        const end = Math.min(offset + chunkSize, file.size);
        const chunk = file.slice(offset, end);
        const result = await uploadBinary(chunkPath(uploadId), chunk, offset, file.size);
        offset = Number(result.receivedBytes);
        if (typeof onProgress === "function") onProgress(offset, file.size);
    }
    return apiRequest(completePath(uploadId), { method: "POST" });
}

/* -------------------- typed endpoints -------------------- */

const FocusAPI = {

    auth: {

        register(name, email, password) {
            return apiRequest("/auth/register", {
                method: "POST",
                auth: false,
                body: { name: name, email: email, password: password }
            });
        },

        login(email, password) {
            return apiRequest("/auth/login", {
                method: "POST",
                auth: false,
                body: { email: email, password: password }
            });
        },

        me() {
            return apiRequest("/auth/me");
        }

    },

    todos: {

        list() {
            return apiRequest("/todos");
        },

        create(text, options) {
            return apiRequest("/todos", { method: "POST", body: { text: text, ...(options || {}) } });
        },

        update(id, changes) {
            return apiRequest("/todos/" + id, { method: "PATCH", body: changes });
        },

        remove(id) {
            return apiRequest("/todos/" + id, { method: "DELETE" });
        },

        clearCompleted() {
            return apiRequest("/todos/completed", { method: "DELETE" });
        }

    },

    settings: {

        get() {
            return apiRequest("/settings");
        },

        update(changes) {
            return apiRequest("/settings", { method: "PUT", body: changes });
        }

    },

    sessions: {

        log(mode, durationSeconds) {
            return apiRequest("/sessions", {
                method: "POST",
                body: { mode: mode, durationSeconds: durationSeconds }
            });
        },

        stats() {
            return apiRequest("/sessions/stats");
        }

    },

    vip: {

        status() {
            return apiRequest("/vip/status");
        },

        plans() {
            return apiRequest("/vip/plans");
        },

        subscription() {
            return apiRequest("/vip/subscription");
        },

        cancelSubscription(subscriptionId) {
            return apiRequest("/vip/subscription/" + encodeURIComponent(subscriptionId) + "/cancel", {
                method: "PATCH"
            });
        },

        themes() {
            return apiRequest("/vip/themes");
        },

        features() {
            return apiRequest("/vip/features");
        },

        advancedStatistics() {
            return apiRequest("/vip/statistics");
        },

        timerOptions() {
            return apiRequest("/vip/timer-options");
        },

        todoOptions() {
            return apiRequest("/vip/todo-options");
        }

    },

    payments: {

        create(planId) {
            return apiRequest("/payments/create", {
                method: "POST",
                body: { planId }
            });
        },

        verify(paymentId) {
            return apiRequest("/payments/verify", {
                method: "POST",
                body: { paymentId }
            });
        },

        mockComplete(paymentId) {
            return apiRequest("/payments/mock/complete", {
                method: "POST",
                body: { paymentId }
            });
        },

        status(paymentId) {
            return apiRequest("/payments/" + encodeURIComponent(paymentId));
        },

        history() {
            return apiRequest("/payments/history");
        }

    },

    admin: {
        dashboard() { return apiRequest("/admin/dashboard"); },
        statistics() { return apiRequest("/admin/statistics"); },
        users(params = {}) {
            const q = new URLSearchParams();
            Object.entries(params).forEach(([k,v]) => { if (v !== undefined && v !== null && v !== "") q.set(k, v); });
            return apiRequest("/admin/users" + (q.toString() ? "?" + q.toString() : ""));
        },
        user(id) { return apiRequest("/admin/users/" + encodeURIComponent(id)); },
        setRole(id, role) { return apiRequest("/admin/users/" + encodeURIComponent(id) + "/role", { method: "PATCH", body: { role } }); },
        setActive(id, active) { return apiRequest("/admin/users/" + encodeURIComponent(id) + "/status", { method: "PATCH", body: { active } }); },
        resetPassword(id, password) { return apiRequest("/admin/users/" + encodeURIComponent(id) + "/reset-password", { method: "POST", body: { password } }); },
        activateVip(id, planId) { return apiRequest("/admin/users/" + encodeURIComponent(id) + "/vip", { method: "POST", body: { planId } }); },
        revokeVip(id) { return apiRequest("/admin/users/" + encodeURIComponent(id) + "/revoke-vip", { method: "POST" }); },
        subscriptions(params = {}) {
            const q = new URLSearchParams(); Object.entries(params).forEach(([k,v]) => { if (v !== undefined && v !== null && v !== "") q.set(k, v); });
            return apiRequest("/admin/subscriptions" + (q.toString() ? "?" + q.toString() : ""));
        },
        cancelSubscription(id) { return apiRequest("/admin/subscriptions/" + encodeURIComponent(id) + "/cancel", { method: "PATCH" }); },
        extendSubscription(id, days) { return apiRequest("/admin/subscriptions/" + encodeURIComponent(id) + "/extend", { method: "PATCH", body: { days } }); },
        settings() { return apiRequest("/admin/settings"); },
        updateSettings(data) { return apiRequest("/admin/settings", { method: "PUT", body: data }); },
        auditLogs(params = {}) { const q = new URLSearchParams(); Object.entries(params).forEach(([k,v]) => { if (v !== undefined && v !== null && v !== "") q.set(k, v); }); return apiRequest("/admin/audit-logs" + (q.toString() ? "?" + q.toString() : "")); },
        payments(params = {}) {
            const q = new URLSearchParams();
            Object.entries(params).forEach(([k,v]) => { if (v !== undefined && v !== null && v !== "") q.set(k, v); });
            return apiRequest("/admin/payments" + (q.toString() ? "?" + q.toString() : ""));
        },
        songs() { return apiRequest("/admin/songs"); },
        createSong(data) { return apiRequest("/admin/songs", { method: "POST", body: data }); },
        uploadSong(data) { return apiRequest("/admin/songs/upload", { method: "POST", body: data }); },
        uploadSongChunked(file, meta, onProgress) { return uploadInChunks({ initPath: "/admin/songs/upload/init", initBody: { ...meta, fileName: file.name, mimeType: file.type, totalBytes: file.size }, chunkPath: id => "/admin/uploads/chunks/" + encodeURIComponent(id), completePath: id => "/admin/songs/upload/" + encodeURIComponent(id) + "/complete", file, onProgress }); },
        updateSong(id, data) { return apiRequest("/admin/songs/" + encodeURIComponent(id), { method: "PATCH", body: data }); },
        deleteSong(id) { return apiRequest("/admin/songs/" + encodeURIComponent(id), { method: "DELETE" }); },
        themes() { return apiRequest("/themes/admin"); },
        createTheme(data) { return apiRequest("/themes/admin", { method: "POST", body: data }); },
        updateTheme(id, data) { return apiRequest("/themes/admin/" + encodeURIComponent(id), { method: "PATCH", body: data }); },
        uploadThemeBackground(id, data) { return apiRequest("/themes/admin/" + encodeURIComponent(id) + "/background", { method: "POST", body: data }); },
        uploadThemeBackgroundChunked(id, file, onProgress) { return uploadInChunks({ initPath: "/themes/admin/background/init", initBody: { themeId: id, fileName: file.name, mimeType: file.type, totalBytes: file.size }, chunkPath: uploadId => "/themes/admin/background/chunk/" + encodeURIComponent(uploadId), completePath: uploadId => "/themes/admin/background/" + encodeURIComponent(uploadId) + "/complete", file, onProgress }); },
        deleteTheme(id) { return apiRequest("/themes/admin/" + encodeURIComponent(id), { method: "DELETE" }); }
    },

    songs: {

        list() {
            return apiRequest("/songs");
        },

        favorites() {
            return apiRequest("/songs/favorites");
        },

        favorite(id) {
            return apiRequest("/songs/" + id + "/favorite", { method: "PUT" });
        },

        unfavorite(id) {
            return apiRequest("/songs/" + id + "/favorite", { method: "DELETE" });
        }

    }

};

/* -------------------------------------------------------------------
   Auth events — todo.js / timer.js / song.js each listen for
   "focus:authenticated" to know it's safe to start fetching user data,
   and "focus:loggedout" to reset/hide themselves.
------------------------------------------------------------------- */

function broadcastAuthenticated(user) {
    document.dispatchEvent(new CustomEvent("focus:authenticated", { detail: { user: user } }));
}

function broadcastLoggedOut() {
    document.dispatchEvent(new CustomEvent("focus:loggedout"));
}
