/* ===================================================================
   Elements
=================================================================== */

// ===== Music Panel =====

const musicPanel = document.getElementById("music-panel");
const musicOverlay = document.getElementById("music-overlay");
const musicList = document.getElementById("music-list");
const musicSearch = document.getElementById("music-search-input");
const musicButton = document.getElementById("music-btn");
const closeMusic = document.getElementById("close-music");

// ===== Audio =====

const audio = document.getElementById("music-audio");

// ===== Main Player =====

const playerTitle = document.getElementById("player-title");
const playerArtist = document.getElementById("player-artist");

const currentTimeEl = document.getElementById("current-time");
const durationTime = document.getElementById("duration-time");

const progressBar =
    document.querySelector(".player-progress .progress");

const progressFill =
    document.getElementById("music-progress");

// ===== Controls =====

const playBtn =
    document.getElementById("play-song");

const prevBtn =
    document.getElementById("prev-song");

const nextBtn =
    document.getElementById("next-song");

const shuffleBtn =
    document.getElementById("shuffle-btn");

const loopBtn =
    document.getElementById("loop-btn");

// ===== Mini Player =====

const musicMiniPlayer =
    document.getElementById("music-mini-player");

const musicMiniTitle =
    document.getElementById("music-mini-title");

const musicMiniArtist =
    document.getElementById("music-mini-artist");

const musicMiniProgress =
    document.getElementById("music-mini-progress-fill");

const musicMiniPlay =
    document.getElementById("music-mini-play");

const musicMiniPrev =
    document.getElementById("music-mini-prev");

const musicMiniNext =
    document.getElementById("music-mini-next");

const musicMiniClose =
    document.getElementById("music-mini-close");


/* ===================================================================
   Variables
=================================================================== */

let SONGS = []; // merged API + local assets/music songs

let favoriteIds = new Set();

let currentSong = -1;

let isPlaying = false;

let isShuffle = false;

let isLoop = false;

/* ===================================================================
   Core Functions
=================================================================== */


function resolveAudioUrl(fileUrl, isLocal = false) {
    if (!fileUrl) return '';
    if (/^https?:\/\//i.test(fileUrl)) return fileUrl;

    // Local frontend assets (assets/music/...) must stay on the frontend
    // origin. Uploaded/backend files (/uploads/...) belong to the API origin.
    if (isLocal) {
        try {
            return new URL(fileUrl.replace(/^\.\//, ''), window.location.origin + '/').toString();
        } catch (_) {
            return fileUrl;
        }
    }

    if (typeof API_BASE_URL === 'string') {
        try {
            return new URL(fileUrl, API_BASE_URL + '/').toString();
        } catch (_) {}
    }

    return fileUrl;
}


// ساخت لیست موزیک‌ها
function renderMusic(list = SONGS){

    musicList.innerHTML = "";

    list.forEach((song)=>{

        const realIndex = SONGS.findIndex(
            item => item.id === song.id
        );

        const item = document.createElement("div");

        item.className = "music-item";

        item.dataset.index = realIndex;

        if (song.is_vip) {
            item.classList.add("vip-song");
        }

        const isFav = favoriteIds.has(song.id);

        item.innerHTML = `

            <div class="music-info">

                <span class="music-title">${song.title}</span>

                <span class="music-artist">${song.artist}</span>

            </div>

            <div class="music-item-right">

                <span class="music-duration">--:--</span>

                ${song.is_vip ? '<span class="music-vip-lock" title="VIP Music"><i class="fa-solid fa-crown"></i></span>' : ''}

                <button class="music-fav-btn ${isFav ? "active" : ""}" title="Favorite">
                    <i class="fa-solid fa-star"></i>
                </button>

            </div>

        `;

        item.addEventListener("click",()=>{

            if (!song.can_play || !song.file_url) {
                openVipMusicPrompt();
                return;
            }

            loadSong(realIndex);

            playMusic();

        });

        item.querySelector(".music-fav-btn")
            .addEventListener("click", (e)=>{

                e.stopPropagation();

                if (song.is_vip && !song.can_play) {
                    openVipMusicPrompt();
                    return;
                }

                if (song.local) {
                    return;
                }

                toggleFavorite(song.id, e.currentTarget);

            });

        musicList.appendChild(item);

    });

}


// بارگذاری آهنگ
function loadSong(index){

    const song = SONGS[index];

    if (!song || !song.can_play || !song.file_url) {
        openVipMusicPrompt();
        return false;
    }

    currentSong = index;

    audio.src = resolveAudioUrl(song.file_url, !!song.local);
    audio.load();

    playerTitle.textContent = song.title;

    playerArtist.textContent = song.artist;

    document.querySelectorAll(".music-item")
        .forEach(item=>item.classList.remove("active"));

    document
        .querySelector(`[data-index="${index}"]`)
        ?.classList.add("active");

    updateMusicMini();

    return true;

}


function findPlayableIndex(startIndex, direction = 1) {

    if (!SONGS.length) return -1;

    let index = startIndex;

    for (let i = 0; i < SONGS.length; i++) {

        index = (index + direction + SONGS.length) % SONGS.length;

        if (SONGS[index].can_play && SONGS[index].file_url) {
            return index;
        }

    }

    return -1;
}


function openVipMusicPrompt() {

    if (typeof openVipPanel === "function") {
        openVipPanel();
    }

}


// پخش
function playMusic(){

    if(currentSong === -1) return;

    audio.play().catch(err=>console.log(err));

    isPlaying = true;

    playBtn.innerHTML =
        '<i class="fa-solid fa-pause"></i>';

    updateMusicMini();

}


// توقف
function pauseMusic(){

    audio.pause();

    isPlaying = false;

    playBtn.innerHTML =
        '<i class="fa-solid fa-play"></i>';

    updateMiniPlayButton();

}


// آهنگ بعدی
function nextSong(){

    if(!SONGS.length) return;

    if(isShuffle){

        const playable = SONGS
            .map((song, index) => ({ song, index }))
            .filter(({ song }) => song.can_play && song.file_url);

        if (!playable.length) return;

        currentSong = playable[Math.floor(Math.random() * playable.length)].index;

    }else{

        currentSong = findPlayableIndex(currentSong, 1);

        if (currentSong === -1) return;

    }

    if (loadSong(currentSong)) playMusic();

}


// آهنگ قبلی
function prevSong(){

    if(!SONGS.length) return;

    currentSong = findPlayableIndex(currentSong, -1);

    if (currentSong === -1) return;

    if (loadSong(currentSong)) playMusic();

}


// زمان
function formatTime(time){

    const min = Math.floor(time/60);

    const sec = Math.floor(time%60);

    return `${min}:${sec.toString().padStart(2,"0")}`;

}


/* ===================================================================
   Favorites
=================================================================== */

async function toggleFavorite(songId, btnEl){

    const isFav = favoriteIds.has(songId);

    try{

        if(isFav){

            await FocusAPI.songs.unfavorite(songId);

            favoriteIds.delete(songId);

        }else{

            await FocusAPI.songs.favorite(songId);

            favoriteIds.add(songId);

        }

        btnEl.classList.toggle("active", !isFav);

    }catch(err){

        console.error("Could not toggle favorite:", err.message);

    }

}


/* ===================================================================
   Mini Player
=================================================================== */

function updateMiniPlayButton(){

    musicMiniPlay.innerHTML = isPlaying

        ? '<i class="fa-solid fa-pause"></i>'

        : '<i class="fa-solid fa-play"></i>';

}


function updateMusicMini(){

    if(currentSong === -1) return;

    musicMiniTitle.textContent =
        SONGS[currentSong].title;

    musicMiniArtist.textContent =
        SONGS[currentSong].artist;

    musicMiniPlayer.classList.add("show");

    updateMiniPlayButton();

}

/* ===================================================================
   Event Listeners
=================================================================== */

// =====================
// Music Panel
// =====================

musicButton.addEventListener("click",()=>{

    musicPanel.classList.add("show");

    musicOverlay.classList.add("show");

});

function closePanel(){

    musicPanel.classList.remove("show");

    musicOverlay.classList.remove("show");

}

closeMusic.addEventListener("click",closePanel);

musicOverlay.addEventListener("click",closePanel);


// =====================
// Search
// =====================

musicSearch.addEventListener("input",()=>{

    const value = musicSearch.value.toLowerCase();

    const filtered = SONGS.filter(song=>{

        return(

            song.title.toLowerCase().includes(value)

            ||

            song.artist.toLowerCase().includes(value)

        );

    });

    renderMusic(filtered);

});


// =====================
// Main Player Controls
// =====================

playBtn.addEventListener("click",()=>{

    if(currentSong === -1){

        currentSong = findPlayableIndex(-1, 1);

        if (currentSong === -1) return;

        if (loadSong(currentSong)) playMusic();

        return;

    }

    isPlaying ? pauseMusic() : playMusic();

});

prevBtn.addEventListener("click",prevSong);

nextBtn.addEventListener("click",nextSong);


// =====================
// Shuffle & Loop
// =====================

shuffleBtn.addEventListener("click",()=>{

    isShuffle = !isShuffle;

    shuffleBtn.classList.toggle("active");

});

loopBtn.addEventListener("click",()=>{

    isLoop = !isLoop;

    audio.loop = isLoop;

    loopBtn.classList.toggle("active");

});


// =====================
// Progress
// =====================

audio.addEventListener("loadedmetadata",()=>{

    durationTime.textContent =
        formatTime(audio.duration);

});


audio.addEventListener("timeupdate",()=>{

    currentTimeEl.textContent =
        formatTime(audio.currentTime);

    if(!audio.duration) return;

    const percent =
        (audio.currentTime / audio.duration) * 100;

    progressFill.style.width =
        percent + "%";

    musicMiniProgress.style.width =
        percent + "%";

});


progressBar.addEventListener("click",(e)=>{

    if(!audio.duration) return;

    const rect =
        progressBar.getBoundingClientRect();

    const percent =
        (e.clientX - rect.left) / rect.width;

    audio.currentTime =
        percent * audio.duration;

});


// =====================
// End Song
// =====================

audio.addEventListener("ended",()=>{

    if(isLoop){

        playMusic();

        return;

    }

    nextSong();

});


// =====================
// Mini Player
// =====================

musicMiniPlay.addEventListener("click",()=>{

    if(currentSong === -1){

        currentSong = findPlayableIndex(-1, 1);

        if (currentSong === -1) return;

        if (loadSong(currentSong)) playMusic();

        return;

    }

    isPlaying ? pauseMusic() : playMusic();

});


musicMiniNext.addEventListener("click",nextSong);

musicMiniPrev.addEventListener("click",prevSong);


musicMiniClose.addEventListener("click",()=>{

    musicMiniPlayer.classList.remove("show");

});

/* ===================================================================
   Initialize — waits for login (see api.js / auth-ui.js)
=================================================================== */

async function initMusic(){

    // Local Music Library must always be available, even for guests.
    // Backend songs/favorites are optional and only loaded when authenticated.
    try {
        const fallbackLocalSongs = (typeof MUSIC_LIBRARY !== "undefined" && Array.isArray(MUSIC_LIBRARY))
            ? MUSIC_LIBRARY.map((song, index) => ({
                id: song.id || `local-library-${index}`,
                title: song.title || "Local Music",
                artist: song.artist || "Local Music",
                file_url: song.file || song.file_url || "",
                is_vip: !!song.is_vip,
                can_play: !song.is_vip || !!window.focusTimerVipActive,
                local: true
            }))
            : [];

        let discoveredLocalSongs = [];
        if (typeof discoverLocalMusic === "function") {
            try {
                discoveredLocalSongs = await discoverLocalMusic();
            } catch (err) {
                console.warn("Local music discovery failed; using music-library.js:", err);
            }
        }

        // music-library.js is authoritative for bundled tracks (including VIP flags).
        // Directory discovery may add extra local files, but never overrides library metadata.
        const libraryByFile = new Map(
            fallbackLocalSongs.map(song => [String(song.file_url || song.file || ""), song])
        );

        const discoveredExtras = (Array.isArray(discoveredLocalSongs) ? discoveredLocalSongs : [])
            .filter(song => !libraryByFile.has(String(song.file_url || song.file || "")))
            .map(song => ({
                ...song,
                is_vip: !!song.is_vip,
                can_play: song.is_vip ? !!window.focusTimerVipActive : true,
                local: true
            }));

        const localSource = [...fallbackLocalSongs, ...discoveredExtras];

        const seen = new Set();
        const merged = [];

        localSource.forEach((song) => {
            const key = `local:${song.file_url || song.file}`;
            if (seen.has(key)) return;
            seen.add(key);
            merged.push(song);
        });

        // Backend music is an optional addition. A guest must never lose the
        // local library just because the API requires authentication.
        if (typeof FocusAuth !== "undefined" && FocusAuth.isLoggedIn()) {
            try {
                const songsResult = await FocusAPI.songs.list();
                const apiSongs = Array.isArray(songsResult.songs) ? songsResult.songs : [];

                apiSongs.forEach((song) => {
                    const key = `api:${song.id}`;
                    if (seen.has(key)) return;
                    seen.add(key);
                    merged.push(song);
                });
            } catch (err) {
                console.warn("Could not load backend music; local library remains available:", err.message);
            }

            try {
                const favoritesResult = await FocusAPI.songs.favorites();
                favoriteIds = new Set(
                    (Array.isArray(favoritesResult.songs) ? favoritesResult.songs : []).map(s => s.id)
                );
            } catch (err) {
                // Favorites are optional; do not hide the music library.
                favoriteIds = new Set();
            }
        } else {
            favoriteIds = new Set();
        }

        SONGS = merged;
        renderMusic();
        updateMiniPlayButton();

    } catch (err) {
        console.error("Could not load music library:", err.message);
    }
}

// Load the local library immediately for guests as well as logged-in users.
if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initMusic, { once: true });
} else {
    initMusic();
}

document.addEventListener("focus:authenticated", initMusic);

document.addEventListener("focus:loggedout", ()=>{

    audio.pause();

    isPlaying = false;
    currentSong = -1;

    SONGS = [];
    favoriteIds = new Set();

    musicList.innerHTML = "";
    musicMiniPlayer.classList.remove("show");

    playerTitle.textContent = "No Music";
    playerArtist.textContent = "Choose a song";

    // Keep local music available after logout.
    initMusic();

});


let newWorker = null;

if ("serviceWorker" in navigator) {

    window.addEventListener("load", async () => {

        const reg = await navigator.serviceWorker.register("/sw.js");

        console.log("✅ Service Worker Registered");

        reg.update();

        setInterval(() => {

            reg.update();

        },60000);

        reg.addEventListener("updatefound",()=>{

            newWorker = reg.installing;

            newWorker.addEventListener("statechange",()=>{

                if(

                    newWorker.state === "installed"

                    &&

                    navigator.serviceWorker.controller

                ){

                    const update = confirm(

                        "🚀 نسخه جدید برنامه منتشر شده است.\n\nآیا مایل به بروزرسانی هستید؟"

                    );

                    if(update){

                        newWorker.postMessage({

                            type:"SKIP_WAITING"

                        });

                    }

                }

            });

        });

    });

    navigator.serviceWorker.addEventListener("controllerchange",()=>{

        window.location.reload();

    });

}


// VIP music message only (no VIP purchase page)
window.openVipMusicPrompt = function () {
    const message = "برای استفاده از این موزیک نیاز به VIP دارید";

    if (typeof showToast === "function") {
        showToast(message);
        return;
    }

    let toast = document.getElementById("music-vip-toast");
    if (!toast) {
        toast = document.createElement("div");
        toast.id = "music-vip-toast";
        toast.style.cssText = `
            position: fixed;
            bottom: 90px;
            right: 50%;
            transform: translateX(50%);
            z-index: 99999;
            padding: 14px 22px;
            border-radius: 16px;
            background: rgba(20,20,20,.75);
            color: #fff;
            backdrop-filter: blur(10px);
        `;
        document.body.appendChild(toast);
    }

    toast.textContent = message;
    toast.style.display = "block";

    clearTimeout(window.musicVipToastTimer);
    window.musicVipToastTimer = setTimeout(() => {
        toast.style.display = "none";
    }, 3000);
};
