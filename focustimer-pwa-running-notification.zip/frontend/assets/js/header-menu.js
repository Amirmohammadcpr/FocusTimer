document.addEventListener('DOMContentLoaded', () => {
    const header = document.querySelector('.app-header');
    const toggle = document.getElementById('header-menu-toggle');
    const menu = document.getElementById('header-mobile-menu');

    if (!header || !toggle || !menu) return;

    const isMobileLayout = () => window.matchMedia('(max-width: 900px)').matches;

    const setOpen = (open) => {
        header.classList.toggle('menu-open', open);
        toggle.setAttribute('aria-expanded', String(open));
        toggle.setAttribute('aria-label', open ? 'بستن منوی هدر' : 'باز کردن منوی هدر');
    };

    toggle.addEventListener('click', (event) => {
        event.stopPropagation();
        setOpen(!header.classList.contains('menu-open'));
    });

    menu.addEventListener('click', (event) => {
        const button = event.target.closest('button, a');
        if (!button) return;

        // Let the existing button/link handlers run, then close the menu.
        if (isMobileLayout()) {
            window.setTimeout(() => setOpen(false), 0);
        }
    });

    document.addEventListener('click', (event) => {
        if (!header.contains(event.target) && header.classList.contains('menu-open')) {
            setOpen(false);
        }
    });

    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && header.classList.contains('menu-open')) {
            setOpen(false);
            toggle.focus();
        }
    });

    window.addEventListener('resize', () => {
        if (!isMobileLayout()) setOpen(false);
    });
});
