$(function () {

    let timerInterval = null;

    let hasStarted = false;

    let focusTime =
        parseInt(localStorage.getItem("focusTime")) || 25;

    let breakTime =
        parseInt(localStorage.getItem("breakTime")) || 5;

    $("#focus-input").val(focusTime);
    $("#break-input").val(breakTime);

    let isFocusing =
        localStorage.getItem("isFocusing") === null
            ? true
            : localStorage.getItem("isFocusing") === "true";

    let remaining =
        parseInt(localStorage.getItem("remaining")) ||
        (isFocusing ? focusTime * 60 : breakTime * 60);

    function saveState() {

        localStorage.setItem(
            "focusTime",
            focusTime
        );

        localStorage.setItem(
            "breakTime",
            breakTime
        );

        localStorage.setItem(
            "remaining",
            remaining
        );

        localStorage.setItem(
            "isFocusing",
            isFocusing
        );
    }

    function formatTime(seconds) {

        const m = Math.floor(seconds / 60);
        const s = seconds % 60;

        return (
            String(m).padStart(2, "0") +
            ":" +
            String(s).padStart(2, "0")
        );
    }

    function updateTimer() {

        $("#timer").text(
            formatTime(remaining)
        );
    }

    function updateUI() {

        if (isFocusing) {

            $("#status")
                .text("Focus Session");

            $("#session-icon")
                .attr(
                    "class",
                    "fas fa-brain"
                );

        } else {

            $("#status")
                .text("Break Time");

            $("#session-icon")
                .attr(
                    "class",
                    "fas fa-mug-hot"
                );
        }

        updateTimer();
        updateMiniPlayer();
    }

    function notifyUser() {

        if (
            Notification.permission ===
            "granted"
        ) {

            new Notification(
                isFocusing
                    ? "Focus Started"
                    : "Break Started"
            );
        }
    }

    function playAlarm() {

        const audio =
            new Audio(
                "assets/audio/alarm.mp3"
            );

        audio.play();
    }

    function pauseTimer() {

        clearInterval(timerInterval);

        timerInterval = null;

        $("#stop-time")
            .addClass("d-none");

        $("#start-time")
            .removeClass("d-none");

        $("#mini-play i")
            .removeClass("fa-pause")
            .addClass("fa-play");
    }

    function updateToggleButton() {

        const icon = $("#toggle-mode i");

        if (hasStarted) {

            // نقش Reset
            icon.removeClass();
            icon.addClass("fas fa-rotate-left");

        } else {

            // نقش Toggle
            icon.removeClass();
            icon.addClass("fas fa-sync-alt");
        }
    }

    function startTimer() {

        if (timerInterval) return;

        hasStarted = true;

        updateToggleButton();

        $("#start-time")
            .addClass("d-none");

        $("#stop-time")
            .removeClass("d-none");

        timerInterval = setInterval(() => {

            remaining--;

            saveState();

            updateTimer();
            updateMiniPlayer();

            if (remaining <= 0) {

                playAlarm();

                isFocusing =
                    !isFocusing;

                remaining =
                    isFocusing
                        ? focusTime * 60
                        : breakTime * 60;

                notifyUser();

                saveState();

                updateUI();
            }

        }, 1000);

        $("#mini-play i")
            .removeClass("fa-play")
            .addClass("fa-pause");
    }


    function resetTimer() {

        pauseTimer();

        hasStarted = false;

        updateToggleButton();

        remaining =
            isFocusing
                ? focusTime * 60
                : breakTime * 60;

        saveState();

        updateTimer();
        updateMiniPlayer();
    }

    $("#start-time").on(
        "click",
        startTimer
    );

    $("#stop-time").on(
        "click",
        pauseTimer
    );

    $("#reset").on(
        "click",
        resetTimer
    );

    function restartCurrentMode() {

        pauseTimer();

        remaining =
            isFocusing
                ? focusTime * 60
                : breakTime * 60;

        hasStarted = false;

        saveState();

        updateUI();
    }

    $("#toggle-mode").on("click", () => {

        // if (hasStarted) {
        //     restartCurrentMode();
        //     return;
        // }

        if (hasStarted) {

            pauseTimer();

            remaining =
                isFocusing
                    ? focusTime * 60
                    : breakTime * 60;

            hasStarted = false;

            updateToggleButton();

            saveState();

            updateUI();

            return;
        }

        isFocusing = !isFocusing;

        remaining =
            isFocusing
                ? focusTime * 60
                : breakTime * 60;

        saveState();

        updateUI();
    });

    $("#focus-input").on(
        "input",
        function () {

            focusTime =
                parseInt(
                    $(this).val()
                ) || 25;

            if (
                isFocusing &&
                !timerInterval
            ) {

                remaining =
                    focusTime * 60;

                updateTimer();
                updateMiniPlayer();
            }

            saveState();
        }
    );

    $("#break-input").on(
        "input",
        function () {

            breakTime =
                parseInt(
                    $(this).val()
                ) || 5;

            if (
                !isFocusing &&
                !timerInterval
            ) {

                remaining =
                    breakTime * 60;

                updateTimer();
                updateMiniPlayer();
            }

            saveState();
        }
    );

    if (
        "Notification" in window
    ) {
        Notification.requestPermission();
    }


    updateUI();



    // miniPlayer

    $("#compact-mode-btn").on("click", function () {

        $("main").addClass("compact");

        $("#mini-player").addClass("show");

    });

    $("#close-mini").on("click", function () {

        $("main").removeClass("compact");

        $("#mini-player").removeClass("show");

    });


    // $("#focus-mode").click(function(){
    //
    //     $("main").fadeOut(250);
    //
    //     $("#mini-player").addClass("show");
    //
    // });

    $("#close-mini").click(function(){

        $("#mini-player").removeClass("show");

        $("main").fadeIn(250);

    });

    function updateMiniPlayer(){

        $("#mini-time").text(formatTime(remaining));

        $("#mini-mode").text(
            isFocusing
                ? "Focus"
                : "Break"
        );

        const totalSeconds =
            isFocusing
                ? focusTime * 60
                : breakTime * 60;

        const percent =
            (remaining / totalSeconds) * 100;

        $("#mini-progress").css(
            "width",
            percent + "%"
        );

    }

    $("#mini-play").on("click",function(){

        if(timerInterval){

            pauseTimer();

        }else{

            startTimer();

        }

    });

    $("#mini-toggle").on("click", function () {

        $("#toggle-mode").trigger("click");

    });

    $("#mini-expand").click(function(){

        $("#fullscreen-btn").click();

    });


    // ======================================================
// Mini Player
// ======================================================

// بروزرسانی اطلاعات Mini Player
    function updateMiniPlayer() {

        $("#mini-time").text(formatTime(remaining));

        $("#mini-mode").text(
            isFocusing ? "Focus" : "Break"
        );

        const totalSeconds =
            (isFocusing ? focusTime : breakTime) * 60;

        const percent =
            (remaining / totalSeconds) * 100;

        $("#mini-progress").css(
            "width",
            percent + "%"
        );

    }

// باز کردن Mini Player
    function openMiniPlayer() {

        $("main").addClass("compact");

        $("#mini-player").addClass("show");

        updateMiniPlayer();

    }

// بستن Mini Player
    function closeMiniPlayer() {

        $("main").removeClass("compact");

        $("#mini-player").removeClass("show");

    }

// ----------------------
// Events
// ----------------------

    $("#compact-mode-btn").on("click", openMiniPlayer);

    $("#close-mini").on("click", closeMiniPlayer);


// Play / Pause

    $("#mini-play").on("click", function () {

        if (timerInterval) {

            pauseTimer();

        } else {

            startTimer();

        }

    });


// Toggle / Reset

    $("#mini-toggle").on("click", function () {

        $("#toggle-mode").trigger("click");

    });


// Fullscreen

    $("#mini-expand").on("click", function () {

        $("#fullscreen-btn").trigger("click");

    });


// بارگذاری اولیه اطلاعات

    updateMiniPlayer();


});
