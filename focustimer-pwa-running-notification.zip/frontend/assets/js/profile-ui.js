/* Profile popover + public app auth behavior + separate user statistics. */
$(function () {
    const profileBtn = $('#profile-btn');
    const profileMenu = $('#profile-menu');
    const statsBtn = $('#user-stats-btn');
    const statsOverlay = $('#user-stats-overlay');
    const statsPanel = $('#user-stats-panel');
    const statsClose = $('#close-user-stats');
    const statsRefresh = $('#user-stats-refresh');

    function setProfileOpen(open) {
        profileMenu.toggleClass('show', open);
        profileBtn.attr('aria-expanded', String(open));
    }

    profileBtn.on('click', function (e) {
        e.stopPropagation();
        const open = !profileMenu.hasClass('show');
        setProfileOpen(open);
    });

    $(document).on('click', function (e) {
        if (!profileMenu.is(e.target) && profileMenu.has(e.target).length === 0 && !profileBtn.is(e.target) && profileBtn.has(e.target).length === 0) {
            setProfileOpen(false);
        }
    });

    $(document).on('keydown', function (e) {
        if (e.key === 'Escape') setProfileOpen(false);
    });

    $(document).on('click', '#profile-vip-action', function () {
        setProfileOpen(false);
        const btn = document.getElementById('vip-btn');
        if (btn) btn.click();
    });

    window.openAuthFromProfile = function () {
        setProfileOpen(false);
        if (typeof window.focusOpenAuth === 'function') {
            window.focusOpenAuth();
        }
    };

    function formatMinutes(seconds) {
        const s = Math.max(0, Number(seconds) || 0);
        const mins = Math.floor(s / 60);
        if (mins < 60) return `${mins} دقیقه`;
        const h = Math.floor(mins / 60);
        const m = mins % 60;
        return m ? `${h} ساعت و ${m} دقیقه` : `${h} ساعت`;
    }

    function formatNumber(value) {
        return new Intl.NumberFormat('fa-IR').format(Number(value) || 0);
    }

    function formatDay(day) {
        if (!day) return '—';
        const d = new Date(`${day}T00:00:00`);
        if (Number.isNaN(d.getTime())) return day;
        return new Intl.DateTimeFormat('fa-IR', { weekday: 'short', month: 'short', day: 'numeric' }).format(d);
    }

    function renderBars(days) {
        const wrap = $('#user-stats-bars');
        wrap.empty();
        const all = Array.isArray(days) ? days : [];
        const byDay = new Map(all.map(d => [d.day, Number(d.focus_seconds) || 0]));
        const rows = [];
        for (let i = 6; i >= 0; i--) {
            const date = new Date();
            date.setHours(0,0,0,0);
            date.setDate(date.getDate() - i);
            const key = date.toISOString().slice(0, 10);
            rows.push({ day: key, seconds: byDay.get(key) || 0 });
        }
        const max = Math.max(1, ...rows.map(r => r.seconds));
        rows.forEach(r => {
            const h = Math.max(8, Math.round((r.seconds / max) * 100));
            wrap.append(`
                <div class="user-stat-bar-col" title="${formatDay(r.day)} — ${formatMinutes(r.seconds)}">
                    <div class="user-stat-bar-track"><span style="height:${h}%"></span></div>
                    <small>${new Intl.DateTimeFormat('fa-IR', { weekday: 'short' }).format(new Date(`${r.day}T12:00:00`))}</small>
                </div>
            `);
        });
    }

    async function loadUserStats() {
        if (!FocusAuth.isLoggedIn()) {
            window.openAuthFromProfile();
            return;
        }
        $('#user-stats-loading').removeClass('d-none');
        $('#user-stats-error').addClass('d-none').text('');
        $('#user-stats-content').addClass('d-none');
        try {
            const result = await FocusAPI.sessions.stats();
            const stats = result.stats || {};
            $('#user-total-sessions').text(formatNumber(stats.total_sessions));
            $('#user-focus-time').text(formatMinutes(stats.total_focus_seconds));
            $('#user-break-time').text(formatMinutes(stats.total_break_seconds));
            $('#user-today-focus').text(formatMinutes(stats.focus_seconds_today));
            renderBars(stats.last7Days || []);
            $('#user-stats-content').removeClass('d-none');
        } catch (err) {
            $('#user-stats-error').removeClass('d-none').text(err.message || 'دریافت آمار ناموفق بود.');
        } finally {
            $('#user-stats-loading').addClass('d-none');
        }
    }

    function openStats() {
        setProfileOpen(false);
        statsOverlay.addClass('show');
        statsPanel.addClass('show');
        loadUserStats();
    }

    statsBtn.on('click', openStats);
    statsRefresh.on('click', loadUserStats);
    statsClose.on('click', () => { statsOverlay.removeClass('show'); statsPanel.removeClass('show'); });
    statsOverlay.on('click', () => { statsOverlay.removeClass('show'); statsPanel.removeClass('show'); });

    window.setProfileUser = function (user) {
        const loggedIn = !!user;
        profileBtn.removeClass('d-none');
        if (!loggedIn) {
            $('#profile-name').text('مهمان');
            $('#profile-email').text('برای ورود یا ثبت‌نام کلیک کنید');
            $('#profile-vip-status').text('حساب رایگان');
            $('#profile-auth-action').removeClass('d-none');
            $('#profile-vip-action').addClass('d-none');
            $('#profile-logout-action').addClass('d-none');
            $('#profile-admin-action').addClass('d-none');
            return;
        }
        $('#profile-name').text(user.name || 'کاربر');
        $('#profile-email').text(user.email || '');
        const isVip = user.isVip === true || user.vip === true;
        $('#profile-vip-status').text(isVip ? 'VIP فعال' : 'حساب رایگان');
        $('#profile-auth-action').addClass('d-none');
        $('#profile-vip-action').removeClass('d-none');
        $('#profile-logout-action').removeClass('d-none');
        if (user?.isAdmin === true || user?.role === 'admin') $('#profile-admin-action').removeClass('d-none'); else $('#profile-admin-action').addClass('d-none');
    };

    // Guest state is the default; auth-ui updates this after login.
    window.setProfileUser(null);
});
