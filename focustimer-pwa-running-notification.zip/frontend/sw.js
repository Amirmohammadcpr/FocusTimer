const CACHE_NAME = 'pomodoro-v3.2-pwa-timer-notification';

const urlsToCache = [
  "./",
  "./index.html",
  "./assets/css/style.css",
  "./assets/css/vip.css",
  "./assets/css/vip-statistics.css",
  "./assets/css/todo.css",
  "./assets/js/api.js",
  "./assets/js/timer.js",
  "./assets/js/todo.js",
  "./assets/js/song.js",
  "./assets/js/music-library.js",
  "./assets/js/vip.js",
  "./assets/js/vip-statistics.js",
  "./assets/css/admin.css",
  "./admin.html",
  "./admin-statistics.html",
  "./vip-statistics.html"
];

self.addEventListener("install", event => {
  self.skipWaiting();
  event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(urlsToCache)));
});

self.addEventListener("activate", event => {
  event.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", event => {
  const req = event.request;
  const url = new URL(req.url);

  // Never intercept API/backend requests from the frontend origin.
  if (url.origin !== self.location.origin) return;
  if (url.pathname.startsWith("/api/")) return;

  if (req.method !== "GET") return;

  event.respondWith(
    caches.match(req).then(cached => cached || fetch(req).then(res => {
      if (res && res.status === 200 && res.type === "basic") {
        const copy = res.clone();
        caches.open(CACHE_NAME).then(cache => cache.put(req, copy));
      }
      return res;
    }).catch(() => caches.match("./index.html")))
  );
});

self.addEventListener("message", event => {
  const data = event.data || {};
  if (data.type === "POMODORO_RUNNING") {
    const isFocus = data.mode === "focus";
    const seconds = Math.max(0, Number(data.remaining) || 0);
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    const timeText = `${String(minutes).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;

    event.waitUntil(
      self.registration.showNotification(
        "Pomodoro - running",
        {
          body: `${isFocus ? "Focus" : "Break"} • ${timeText} remaining`,
          icon: "/assets/icons/icon-192.png",
          badge: "/assets/icons/icon-192.png",
          tag: "pomodoro-running",
          requireInteraction: true,
          silent: true,
          timestamp: Number(data.endTime) || Date.now(),
          data: { mode: data.mode, endTime: data.endTime, total: data.total }
        }
      )
    );
    return;
  }

  if (data.type === "POMODORO_STOPPED") {
    event.waitUntil(
      self.registration.getNotifications({ tag: "pomodoro-running" }).then(notifications => {
        notifications.forEach(notification => notification.close());
      })
    );
    return;
  }

  if (data.type === "POMODORO_FINISHED") {
    event.waitUntil(
      self.registration.getNotifications({ tag: "pomodoro-running" }).then(notifications => {
        notifications.forEach(notification => notification.close());
      }).then(() => self.registration.showNotification(
        data.mode === "focus" ? "Focus Session Done 🍅" : "Break Time Finished ☕",
        {
          body: data.mode === "focus" ? "Take a short break" : "Back to focus!",
          icon: "/assets/icons/icon-192.png",
          badge: "/assets/icons/icon-192.png",
          tag: "pomodoro-finished"
        }
      ))
    );
  }
  if (data.type === "SYNC_TODO") {
    console.log("Sync received", data.payload);
  }
});
