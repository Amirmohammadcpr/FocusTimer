(() => {
    const $ = (id) => document.getElementById(id);
    const fa = (v) => Number(v || 0).toLocaleString('fa-IR');
    const formatHours = (s) => (Number(s || 0) / 3600).toFixed(1);
    const formatMinutes = (s) => Math.round(Number(s || 0) / 60);
    const dateFa = (v) => {
        if (!v) return '—';
        const d = new Date(String(v).length === 10 ? `${v}T00:00:00` : v);
        if (Number.isNaN(d.getTime())) return v;
        return new Intl.DateTimeFormat('fa-IR', { month: 'short', day: 'numeric' }).format(d);
    };
    const timeFa = (v) => {
        if (!v) return '—';
        const d = new Date(v);
        return Number.isNaN(d.getTime()) ? v : new Intl.DateTimeFormat('fa-IR', { dateStyle: 'short', timeStyle: 'short' }).format(d);
    };
    const hourFa = (hour) => hour == null ? '—' : `${String(Number(hour)).padStart(2, '0')}:00 تا ${String((Number(hour) + 1) % 24).padStart(2, '0')}:00`;

    function back() { window.location.href = 'index.html'; }
    $('vip-back').addEventListener('click', back);
    $('vip-auth-back').addEventListener('click', back);

    function showDenied(message) {
        $('vip-auth-message').textContent = message;
        $('vip-auth').classList.remove('d-none');
        $('vip-app').classList.add('d-none');
    }

    function renderChart(days) {
        const chart = $('focus-chart');
        const labels = $('focus-labels');
        chart.innerHTML = '';
        labels.innerHTML = '';
        if (!days.length) {
            chart.innerHTML = '<div class="vip-empty">هنوز داده‌ای برای نمایش وجود ندارد.</div>';
            return;
        }
        const max = Math.max(...days.map(d => Number(d.focus_seconds || 0)), 60);
        days.forEach((item, i) => {
            const wrap = document.createElement('div');
            wrap.className = 'vip-bar-wrap';
            const bar = document.createElement('div');
            bar.className = 'vip-bar';
            bar.style.height = `${Math.max(4, (Number(item.focus_seconds || 0) / max) * 100)}%`;
            bar.title = `${dateFa(item.day)} · ${formatMinutes(item.focus_seconds)} دقیقه`;
            wrap.appendChild(bar);
            chart.appendChild(wrap);
            if (i % 3 === 0 || i === days.length - 1) {
                const label = document.createElement('span');
                label.textContent = dateFa(item.day);
                labels.appendChild(label);
            } else {
                labels.appendChild(document.createElement('span'));
            }
        });
    }

    function renderDaily(days) {
        const target = $('daily-list');
        if (!days.length) { target.innerHTML = '<div class="vip-empty">هنوز جلسه‌ای ثبت نشده است.</div>'; return; }
        target.innerHTML = days.slice().reverse().map(d => `
            <div class="vip-session-row">
                <div><strong>${dateFa(d.day)}</strong><small>${fa(d.sessions)} جلسه</small></div>
                <strong>${fa(formatMinutes(d.focus_seconds))} دقیقه</strong>
            </div>`).join('');
    }

    function renderSessions(rows) {
        const target = $('session-list');
        if (!rows.length) { target.innerHTML = '<div class="vip-empty">هنوز جلسه Focus ثبت نشده است.</div>'; return; }
        target.innerHTML = rows.slice(0, 12).map(s => `
            <div class="vip-session-row">
                <div><strong>${formatMinutes(s.duration_seconds)} دقیقه Focus</strong><small>${timeFa(s.completed_at)}</small></div>
                <i class="fa-solid fa-brain" style="color:#f5d774"></i>
            </div>`).join('');
    }

    function render(stats) {
        $('m-focus-sessions').textContent = fa(stats.focus_sessions);
        $('m-focus-time').textContent = formatHours(stats.total_focus_seconds);
        $('m-average').textContent = fa(formatMinutes(stats.average_focus_seconds));
        const trend = Number(stats.trendPercent || 0);
        const trendEl = $('m-trend');
        trendEl.textContent = `${trend > 0 ? '+' : ''}${trend.toLocaleString('fa-IR')}٪`;
        trendEl.className = trend >= 0 ? 'trend up' : 'trend down';

        $('ins-best-day').textContent = stats.bestDay ? `${dateFa(stats.bestDay.day)} · ${fa(formatMinutes(stats.bestDay.focus_seconds))} دقیقه` : '—';
        $('ins-longest').textContent = stats.longestSession ? `${fa(formatMinutes(stats.longestSession.duration_seconds))} دقیقه` : '—';
        $('ins-streak').textContent = `${fa(stats.streak)} روز`;
        $('ins-peak-hour').textContent = stats.peakHour ? hourFa(stats.peakHour.hour) : '—';

        renderChart(stats.daily || []);
        renderDaily(stats.daily || []);
        renderSessions(stats.last30FocusSessions || []);
    }

    async function load() {
        $('vip-loading').classList.remove('d-none');
        $('vip-error').classList.add('d-none');
        $('vip-content').classList.add('d-none');
        try {
            const result = await FocusAPI.vip.advancedStatistics();
            render(result.stats || {});
            $('vip-content').classList.remove('d-none');
        } catch (err) {
            $('vip-error').textContent = err.status === 403 ? 'این صفحه فقط برای کاربران VIP فعال است.' : (err.message || 'خطا در دریافت آمار.');
            $('vip-error').classList.remove('d-none');
        } finally {
            $('vip-loading').classList.add('d-none');
        }
    }

    async function boot() {
        if (!FocusAuth.isLoggedIn()) return showDenied('برای مشاهده آمار VIP ابتدا وارد حساب شوید.');
        try {
            const me = await FocusAPI.auth.me();
            const result = await FocusAPI.vip.status();
            if (!result.vip?.active) return showDenied('این صفحه فقط برای اشتراک VIP فعال است.');
            $('vip-auth').classList.add('d-none');
            $('vip-app').classList.remove('d-none');
            $('vip-welcome').textContent = `${me.user?.name || 'کاربر'} · تحلیل عملکرد تمرکز شما`;
            await load();
        } catch (err) {
            showDenied(err.message || 'دسترسی به آمار ممکن نیست.');
        }
    }

    $('vip-refresh').addEventListener('click', async () => {
        const btn = $('vip-refresh');
        btn.disabled = true;
        try { await load(); } finally { btn.disabled = false; }
    });

    boot();
})();
