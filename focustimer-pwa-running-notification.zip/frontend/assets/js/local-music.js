/*
 * Local music discovery for FocusTimer.
 *
 * Static hosting does not provide a directory-listing API by default. We first
 * try the browser-visible directory index (works with Python http.server and
 * Apache directory indexes). If the host blocks directory listing, SONGS can
 * still be supplied by music-library.js as a fallback.
 */
(function () {
  const AUDIO_EXTENSIONS = new Set([
    'mp3', 'wav', 'ogg', 'oga', 'aac', 'm4a', 'webm'
  ]);

  function titleFromFileName(fileName) {
    const withoutExt = fileName.replace(/\.[^.]+$/, '');
    return withoutExt
      .replace(/[_-]+/g, ' ')
      .replace(/\s+/g, ' ')
      .trim() || fileName;
  }

  function localSong(fileName) {
    const encodedPath = 'assets/music/' + encodeURIComponent(fileName).replace(/%2F/gi, '/');
    return {
      id: 'local-' + btoa(unescape(encodeURIComponent(fileName)))
        .replace(/[^a-zA-Z0-9_-]/g, ''),
      title: titleFromFileName(fileName),
      artist: 'Local Music',
      file_url: encodedPath,
      is_vip: false,
      can_play: true,
      local: true
    };
  }

  async function discoverLocalMusic() {
    const candidates = [
      'assets/music/',
      './assets/music/'
    ];

    for (const directoryUrl of candidates) {
      try {
        const response = await fetch(directoryUrl, { cache: 'no-store' });
        if (!response.ok) continue;

        const contentType = response.headers.get('content-type') || '';
        if (!contentType.includes('text/html')) continue;

        const html = await response.text();
        const doc = new DOMParser().parseFromString(html, 'text/html');
        const files = [];

        doc.querySelectorAll('a[href]').forEach((link) => {
          const href = link.getAttribute('href') || '';
          if (!href || href.endsWith('/')) return;

          try {
            const url = new URL(href, new URL(directoryUrl, window.location.href));
            const pathName = decodeURIComponent(url.pathname);
            const fileName = pathName.split('/').pop() || '';
            const ext = fileName.split('.').pop().toLowerCase();
            if (AUDIO_EXTENSIONS.has(ext)) files.push(fileName);
          } catch (_) {
            // Ignore malformed directory entries.
          }
        });

        return Array.from(new Set(files))
          .sort((a, b) => a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' }))
          .map(localSong);
      } catch (_) {
        // Try the next candidate / fallback library.
      }
    }

    return [];
  }

  window.discoverLocalMusic = discoverLocalMusic;
})();
